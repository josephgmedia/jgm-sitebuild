$ErrorActionPreference = 'Stop'
try {
    $extensionId = 'studio.artist.motiondock'
    $extensionRoot = Join-Path $env:APPDATA 'Adobe\CEP\extensions'
    $target = Join-Path $extensionRoot $extensionId
    $source = $PSScriptRoot
    if (-not (Test-Path -LiteralPath (Join-Path $source 'CSXS\manifest.xml'))) { throw 'Extract the full ZIP before running the installer.' }
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    foreach ($name in @('CSXS', 'client', 'host')) {
        Copy-Item -LiteralPath (Join-Path $source $name) -Destination $target -Recurse -Force
    }
    # Unsigned local CEP development panels require this user-level Adobe setting.
    $debugKey = 'HKCU:\Software\Adobe\CSXS.12'
    New-Item -Path $debugKey -Force | Out-Null
    New-ItemProperty -Path $debugKey -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
    Write-Host 'Motion Dock installed for your Windows account.' -ForegroundColor Green
    Write-Host 'Restart After Effects 2026, then choose Window > Extensions > Motion Dock.'
    Write-Host 'Dock the panel by dragging its tab beside your other panels.'
    Write-Host "Installed files: $target"
    Write-Host 'This installer enabled unsigned local CEP panels (CSXS.12 PlayerDebugMode).'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
