/* Adapted from the user-supplied Convert to Shape Controller.jsx. */
var MotionDockControllers = {actions:{convert:function(comp,args){
    var reports=[]; function alert(text){ reports.push(String(text)); }
    if (!(comp instanceof CompItem) || !comp.selectedLayers.length) {
        alert('Open a composition and select controller layers.'); return;
    }
    var selected = comp.selectedLayers, layers = [], converted = [], retained = [];
    var safeEffects = {
        'ADBE Slider Control': true, 'ADBE Angle Control': true,
        'ADBE Checkbox Control': true, 'ADBE Color Control': true,
        'ADBE Point Control': true, 'ADBE Point3D Control': true,
        'ADBE Layer Control': true
    };
    for (var i = 0; i < selected.length; i++) layers.push(selected[i]);
    layers.sort(function (a, b) { return b.index - a.index; });
    function solid(l) {
        return l instanceof AVLayer && l.source && l.source.mainSource instanceof SolidSource;
    }
    function reason(l) {
        if (!(l.nullLayer || solid(l))) return 'requires solid or null source';
        if (l.timeRemapEnabled) return 'time remapping';
        if (l.property('ADBE Mask Parade').numProperties) return 'masks';
        var styles = l.property('ADBE Layer Styles');
        if (styles) {
            for (var st = 1; st <= styles.numProperties; st++) {
                var style = styles.property(st);
                if (style.matchName !== 'ADBE Blend Options Group') {
                    try { if (style.enabled) return 'enabled layer styles'; } catch (_) { return 'layer styles'; }
                }
            }
        }
        if (solid(l) && l.source.pixelAspect !== comp.pixelAspect) return 'different source pixel aspect';
        var fx = l.property('ADBE Effect Parade');
        for (var n = 1; n <= fx.numProperties; n++) {
            if (!safeEffects[fx.property(n).matchName] && fx.property(n).matchName !== 'ADBE Timecode')
                return 'visual or unsupported effect: ' + fx.property(n).name;
        }
        return '';
    }
    function raw(p) { return p.valueAtTime(comp.time, true); }
    function copy(p, q) {
        try { copyValue(p, q); }
        catch (err) {
            throw Error('Property ' + (p ? p.name + ' [' + p.matchName + ']' : '(unknown)') + ': ' + err.toString());
        }
    }
    function copyValue(p, q) {
        if (!p || !q || p.propertyValueType === PropertyValueType.NO_VALUE) return;
        if (p.propertyValueType === PropertyValueType.CUSTOM_VALUE)
            throw Error('Unsupported property: ' + p.name);
        var expression = p.canSetExpression ? p.expression : '';
        var enabled = p.canSetExpression ? p.expressionEnabled : false;
        if (q.canSetExpression) q.expression = '';
        while (q.numKeys) q.removeKey(1);
        if (p.numKeys) {
            for (var k = 1; k <= p.numKeys; k++) q.setValueAtTime(p.keyTime(k), p.keyValue(k));
            for (var k = 1; k <= p.numKeys; k++) {
                q.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), p.keyOutInterpolationType(k));
                if (p.keyInInterpolationType(k) !== KeyframeInterpolationType.HOLD &&
                    p.keyOutInterpolationType(k) !== KeyframeInterpolationType.HOLD) {
                    q.setTemporalEaseAtKey(k, p.keyInTemporalEase(k), p.keyOutTemporalEase(k));
                    q.setTemporalContinuousAtKey(k, p.keyTemporalContinuous(k));
                    q.setTemporalAutoBezierAtKey(k, p.keyTemporalAutoBezier(k));
                }
                if (p.isSpatial) {
                    q.setSpatialTangentsAtKey(k, p.keyInSpatialTangent(k), p.keyOutSpatialTangent(k));
                    q.setSpatialContinuousAtKey(k, p.keySpatialContinuous(k));
                    q.setSpatialAutoBezierAtKey(k, p.keySpatialAutoBezier(k));
                    if (k > 1 && k < p.numKeys) q.setRovingAtKey(k, p.keyRoving(k));
                }
                try { q.setLabelAtKey(k, p.keyLabel(k)); } catch (_) {}
            }
        } else q.setValue(raw(p));
        if (expression) {
            q.expression = expression; q.expressionEnabled = enabled;
        }
        // Scripting readback can equal the source even while expressions see
        // a float32-sized error. Always install the guard on static sliders.
        // Existing expressions and keyed sliders are left intact.
        if (p.matchName === 'ADBE Slider Control-0001' && !p.numKeys && !expression) {
            var before = raw(p);
            // Remove only tiny representation noise already present in readback.
            // Do not impose a fixed number of decimal places on the controller.
            var sourceTolerance = Math.max(1e-12, Math.abs(before) * 1e-9);
            var preserved = before;
            for (var digits = 0; digits <= 12; digits++) {
                var factor = Math.pow(10, digits);
                var candidate = Math.round(before * factor) / factor;
                if (Math.abs(candidate - before) <= sourceTolerance) {
                    preserved = candidate; break;
                }
            }
            var tolerance = Math.max(1, Math.abs(preserved)) * 1e-7;
            q.expression = '// Preserve the static value through AE slider precision conversion.\n' +
                'Math.abs(value - (' + preserved.toString() + ')) <= ' + tolerance.toString() +
                ' ? ' + preserved.toString() + ' : value;';
            q.expressionEnabled = true;
        }
    }

    function tree(a, b) {
        if (a.numProperties !== b.numProperties) throw Error('Effect parameter layout differs: ' + a.name);
        for (var n = 1; n <= a.numProperties; n++) {
            var p = a.property(n), q = b.property(n);
            if (!q || p.matchName !== q.matchName) throw Error('Parameter mismatch: ' + p.name);
            if (p.propertyType === PropertyType.PROPERTY) copy(p, q);
            else tree(p, q);
        }
    }
    function rectangle(l, source) {
        var root = l.property('ADBE Root Vectors Group');
        root.addProperty('ADBE Vector Group');
        var group = root.property(1); group.name = 'Original Solid';
        var contents = group.property('ADBE Vectors Group');
        contents.addProperty('ADBE Vector Shape - Rect');
        contents.property(1).property('ADBE Vector Rect Size').setValue([source.width, source.height]);
        contents.addProperty('ADBE Vector Graphic - Fill');
        contents.property(2).property('ADBE Vector Fill Color').setValue(source.mainSource.color);
        group.property('ADBE Vector Transform Group').property('ADBE Vector Position')
            .setValue([source.width / 2, source.height / 2]);
    }
    function transforms(a, b) {
        var src = a.property('ADBE Transform Group'), dst = b.property('ADBE Transform Group');
        var sourcePosition = src.property('ADBE Position');
        var targetPosition = dst.property('ADBE Position');
        var separated = sourcePosition.dimensionsSeparated;
        targetPosition.dimensionsSeparated = separated;
        // Never enumerate every transform child. AE exposes hidden separation
        // followers and 3D-only properties on 2D layers, but refuses writes.
        var names = ['ADBE Anchor Point', 'ADBE Scale', 'ADBE Rotate Z', 'ADBE Opacity'];
        if (a.threeDLayer) {
            names.push('ADBE Orientation', 'ADBE Rotate X', 'ADBE Rotate Y');
        }
        if (separated) {
            var dimensions = a.threeDLayer ? 3 : 2;
            for (var d = 0; d < dimensions; d++) {
                copy(sourcePosition.getSeparationFollower(d), targetPosition.getSeparationFollower(d));
            }
        } else copy(sourcePosition, targetPosition);
        for (var n = 0; n < names.length; n++) {
            copy(src.property(names[n]), dst.property(names[n]));
        }
    }
    function markers(a, b) {
        var src = a.property('ADBE Marker'), dst = b.property('ADBE Marker');
        // An empty marker property has no static value to copy.
        // Marker properties accept MarkerValue keys, not ordinary setValue.
        for (var k = 1; k <= src.numKeys; k++) {
            dst.setValueAtTime(src.keyTime(k), src.keyValue(k));
        }
    }
    function references(old) {
        var refs = [];
        function scan(group) {
            for (var n = 1; n <= group.numProperties; n++) {
                var p = group.property(n);
                if (p.propertyType !== PropertyType.PROPERTY) scan(p);
                else if (p.propertyValueType === PropertyValueType.LAYER_INDEX) {
                    if (p.numKeys) {
                        for (var k = 1; k <= p.numKeys; k++)
                            if (p.keyValue(k) === old.index) refs.push({p:p, k:k});
                    } else if (raw(p) === old.index) refs.push({p:p, k:0});
                }
            }
        }
        for (var n = 1; n <= comp.numLayers; n++)
            scan(comp.layer(n).property('ADBE Effect Parade'));
        return refs;
    }
    function adaptSolidTimeSource(sourceLayer, effect) {
        // Time Source 1 = Layer Source. A shape has no footage/timecode source.
        // Solids carry a zero-start source; reproduce it with Custom mode.
        var mode = effect.property('ADBE Timecode-0009');
        if (mode.numKeys || (mode.canSetExpression && mode.expressionEnabled)) {
            throw Error('Animated/expression Time Source needs a source-independent expression before conversion.');
        }
        if (mode.value !== 1) return;
        var frameRate = comp.frameRate;
        try {
            if (sourceLayer.source.frameRate > 0) frameRate = sourceLayer.source.frameRate;
        } catch (_) {}
        mode.setValue(3);
        effect.property('ADBE Timecode-0003').setValue(frameRate);
        effect.property('ADBE Timecode-0004').setValue(0);
        // Still solid footage has no embedded drop-frame timecode metadata.
        effect.property('ADBE Timecode-0008').setValue(0);
    }
    function expressionLiteral(text) {
        return '"' + text.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
            .replace(/\r/g, '\\r').replace(/\n/g, '\\n') + '"';
    }
    function preserveTimecodeRaster(layer, sourceLayer, sourceEffectIndex, targetEffectIndex) {
        var effects = layer.property('ADBE Effect Parade');
        var sourcePoint = sourceLayer.property('ADBE Effect Parade').property(sourceEffectIndex)
            .property('ADBE Timecode-0005');
        var point = sourcePoint.valueAtTime(comp.time, false);
        var shiftX = Math.floor(point[0] - comp.width/2);
        var shiftY = Math.floor(point[1] - comp.height/2);
        var input = sourcePoint.expressionEnabled && sourcePoint.expression ?
            'eval(' + expressionLiteral(sourcePoint.expression) + ')' : 'value';
        // Store the original point directly in Timecode's existing value/keys.
        // A fixed integer rebase preserves the subpixel raster phase.
        effects.property(targetEffectIndex).property('ADBE Timecode-0005').expression =
            'var p = ' + input + ';\n[p[0] - (' + shiftX + '), p[1] - (' + shiftY + ')];';
        effects.addProperty('ADBE Geometry2');
        var transform = effects.property(effects.numProperties);
        transform.name = 'Preserve Timecode Render';
        transform.enabled = true;
        transform.property('ADBE Geometry2-0011').setValue(0);
        transform.property('ADBE Geometry2-0001').expression =
            'var a = thisLayer.anchorPoint; [a[0] - (' + shiftX + '), a[1] - (' + shiftY + ')];';
        transform.property('ADBE Geometry2-0002').expression =
            'var p = thisLayer.toComp(thisLayer.anchorPoint); [p[0], p[1]];';
        transform.property('ADBE Geometry2-0003').expression =
            'var l = thisLayer; var s = 1; while (true) { s *= l.transform.scale[1]/100; if (!l.hasParent) break; l = l.parent; } s * 100;';
        transform.property('ADBE Geometry2-0004').expression =
            'var l = thisLayer; var s = 1; while (true) { s *= l.transform.scale[0]/100; if (!l.hasParent) break; l = l.parent; } s * 100;';
        transform.property('ADBE Geometry2-0007').expression =
            'var l = thisLayer; var r = 0; while (true) { r += l.transform.rotation; if (!l.hasParent) break; l = l.parent; } r;';
        transform.property('ADBE Geometry2-0009').setValue(0);
        transform.property('ADBE Geometry2-0010').setValue(0);
    }
    function removeUnusedSolidSource(source) {
        if (!source) return;
        try {
            if (source.mainSource instanceof SolidSource && source.usedIn.length === 0) {
                source.remove();
            }
        } catch (err) {
            retained.push('Unused source cleanup failed: ' + err.toString());
        }
    }

    try {
        for (var idx = 0; idx < layers.length; idx++) {
            var old = layers[idx], name = old.name, replacement = null;
            var why = reason(old);
            if (why) { retained.push(name + ': ' + why); continue; }
            var locked = old.locked, children = [], mattes = [], refs = [];
            try {
                old.locked = false;
                for (var n = 1; n <= comp.numLayers; n++) {
                    var l = comp.layer(n);
                    if (l.parent === old) children.push(l);
                    if (l.trackMatteLayer === old) mattes.push({l:l, type:l.trackMatteType});
                }
                replacement = comp.layers.addShape();
                replacement.name = name + '__SHAPE_PENDING__';
                replacement.moveBefore(old);
                replacement.threeDLayer = old.threeDLayer;
                replacement.setParentWithJump(old.parent);
                replacement.stretch = old.stretch;
                replacement.startTime = old.startTime;
                replacement.inPoint = old.inPoint;
                replacement.outPoint = old.outPoint;
                var settings = ['label','shy','solo','enabled','guideLayer','motionBlur',
                    'blendingMode','preserveTransparency','comment','autoOrient','quality'];
                for (var s = 0; s < settings.length; s++) replacement[settings[s]] = old[settings[s]];
                replacement.adjustmentLayer = old.adjustmentLayer;
                if (!old.nullLayer) rectangle(replacement, old.source);
                transforms(old, replacement);
                var a = old.property('ADBE Effect Parade'), b = replacement.property('ADBE Effect Parade');
                for (var f = 1; f <= a.numProperties; f++) {
                    var effect = a.property(f), match = effect.matchName;
                    b.addProperty(match);
                    var newEffect = b.property(f);
                    newEffect.name = effect.name; newEffect.enabled = effect.enabled;
                    tree(effect, newEffect);
                    if (match === 'ADBE Timecode') adaptSolidTimeSource(old, newEffect);

                }
                for (var tc = 1; tc <= a.numProperties; tc++) {
                    if (a.property(tc).matchName === 'ADBE Timecode') {
                        preserveTimecodeRaster(replacement, old, tc, tc);
                    }
                }
                markers(old, replacement);
                if (old.hasTrackMatte) replacement.setTrackMatte(old.trackMatteLayer, old.trackMatteType);
                // Gather after inserting the replacement; AE has adjusted layer indices.
                refs = references(old);
                for (var r = 0; r < refs.length; r++) {
                    if (refs[r].k) refs[r].p.setValueAtKey(refs[r].k, replacement.index);
                    else refs[r].p.setValue(replacement.index);
                }
                for (var c = 0; c < children.length; c++) children[c].setParentWithJump(replacement);
                for (var m = 0; m < mattes.length; m++) mattes[m].l.setTrackMatte(replacement, mattes[m].type);
            } catch (err) {
                // The original remains until construction and relinking succeed.
                for (var c = 0; c < children.length; c++) {
                    try { children[c].setParentWithJump(old); } catch (_) {}
                }
                for (var m = 0; m < mattes.length; m++) {
                    try { mattes[m].l.setTrackMatte(old, mattes[m].type); } catch (_) {}
                }
                for (var r = 0; r < refs.length; r++) {
                    try {
                        if (refs[r].k) refs[r].p.setValueAtKey(refs[r].k, old.index);
                        else refs[r].p.setValue(old.index);
                    } catch (_) {}
                }
                if (replacement) { try { replacement.remove(); } catch (_) {} }
                old.locked = locked;
                retained.push(name + ': copy failed; original retained (' + err.toString() + ')');
                continue;
            }
            // Capture the source before removing the successfully replaced layer.
            var oldSource = old.source;
            old.remove();
            replacement.name = name;
            replacement.locked = locked;
            converted.push(replacement);
            removeUnusedSolidSource(oldSource);
        }
        for (var n = 1; n <= comp.numLayers; n++) comp.layer(n).selected = false;
        for (var n = 0; n < converted.length; n++) converted[n].selected = true;
        if (retained.length) alert('Converted: ' + converted.length + '\n\nOriginal layers retained to preserve their behavior:\n' + retained.join('\n'));
    } catch (err) {
        alert('Conversion stopped: ' + err.toString() + '\nUse Undo to restore the operation.');
    } finally {}

    return "Converted "+converted.length+" controller layers to shapes."+(reports.length?" "+reports.join(" "):"");

}}};
