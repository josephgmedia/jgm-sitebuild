var MotionDockCrops = (function () {
    var H = MotionDock.helpers, jobs = {}, serial = 0;
    function ok(message, fields) { var r = fields || {}; r.ok = true; r.message = message; return r; }
    function sourceTime(l, time) {
        var t = l.timeRemapEnabled ? l.property('ADBE Time Remapping').valueAtTime(time, false) : (time - l.startTime) * 100 / l.stretch;
        return Math.max(0, Math.min(l.source.duration - l.source.frameDuration, t));
    }
    function selectedTargets(c, single) {
        var ls = c.selectedLayers, out = [];
        if (!ls.length) out.push({ comp: c, time: c.time, layer: null });
        else for (var i = 0; i < ls.length; i++) {
            if (!(ls[i].source instanceof CompItem)) H.fail('Select precomp layers, or deselect layers to crop the active composition.');
            var exists = false; for (var j = 0; j < out.length; j++) if (out[j].comp === ls[i].source) exists = true;
            if (!exists) out.push({ comp: ls[i].source, time: sourceTime(ls[i], c.time), layer: ls[i] });
        }
        if (single && out.length !== 1) H.fail('Whole Animation processes one composition at a time.');
        return out;
    }
    function cubic(p0,p1,p2,p3,t) { var u=1-t; return u*u*u*p0+3*u*u*t*p1+3*u*t*t*p2+t*t*t*p3; }
    function roots(p0,p1,p2,p3) {
        var a=-p0+3*p1-3*p2+p3,b=2*(p0-2*p1+p2),cc=p1-p0,out=[];
        if (Math.abs(a)<1e-10) { if (Math.abs(b)>1e-10) out.push(-cc/b); }
        else { var d=b*b-4*a*cc; if(d>=0){out.push((-b+Math.sqrt(d))/(2*a));out.push((-b-Math.sqrt(d))/(2*a));} }
        return out;
    }
    function maskBounds(shape) {
        var v=shape.vertices,ins=shape.inTangents,outs=shape.outTangents;
        if (!v || !v.length) H.fail('The mask has no vertices.');
        var bounds=[Infinity,Infinity,-Infinity,-Infinity], n=shape.closed?v.length:v.length-1;
        function add(x,y){bounds[0]=Math.min(bounds[0],x);bounds[1]=Math.min(bounds[1],y);bounds[2]=Math.max(bounds[2],x);bounds[3]=Math.max(bounds[3],y);}
        for(var i=0;i<v.length;i++)add(v[i][0],v[i][1]);
        for(i=0;i<n;i++){
            var j=(i+1)%v.length,p0=v[i],p1=[p0[0]+outs[i][0],p0[1]+outs[i][1]],p3=v[j],p2=[p3[0]+ins[j][0],p3[1]+ins[j][1]];
            var ts=roots(p0[0],p1[0],p2[0],p3[0]).concat(roots(p0[1],p1[1],p2[1],p3[1]));
            for(var k=0;k<ts.length;k++)if(ts[k]>0&&ts[k]<1)add(cubic(p0[0],p1[0],p2[0],p3[0],ts[k]),cubic(p0[1],p1[1],p2[1],p3[1],ts[k]));
        }
        return bounds;
    }
    function rect(bounds,padding) {
        if (!(bounds instanceof Array) || bounds.length!==4) H.fail('No visible content was found.');
        for(var i=0;i<4;i++)if(!isFinite(Number(bounds[i])))H.fail('Invalid crop bounds.');
        var x=Math.floor(bounds[0]-padding),y=Math.floor(bounds[1]-padding),w=Math.ceil(bounds[2]+padding)-x,h=Math.ceil(bounds[3]+padding)-y;
        if(w<1||h<1||w>30000||h>30000)H.fail('Crop dimensions must be between 1 and 30,000 pixels. Check Padding.');
        return {x:x,y:y,width:w,height:h};
    }
    function offsetValue(value,x,y,isShape) {
        if(!isShape){var out=value.slice(0);out[0]-=x;out[1]-=y;return out;}
        var shape=new Shape(),vertices=[];
        for(var i=0;i<value.vertices.length;i++)vertices.push([value.vertices[i][0]-x,value.vertices[i][1]-y]);
        shape.vertices=vertices;shape.inTangents=value.inTangents;shape.outTangents=value.outTangents;shape.closed=value.closed;
        var attrs=['featherSegLocs','featherRelSegLocs','featherRadii','featherInterps','featherTensions','featherTypes','featherRelCornerAngles'];
        for(i=0;i<attrs.length;i++)try{if(value[attrs[i]]!==undefined)shape[attrs[i]]=value[attrs[i]];}catch(_){}
        return shape;
    }
    function offsetPlan(p,c,x,y,isShape) {
        var plan={p:p,keys:[],value:null,baked:p.expressionEnabled,expression:p.expression,enabled:p.expressionEnabled};
        if(plan.baked){
            for(var i=0;i<=Math.ceil(c.duration/c.frameDuration);i++){var t=Math.min(c.duration,i*c.frameDuration);plan.keys.push({time:t,value:offsetValue(p.valueAtTime(t,false),x,y,isShape)});}
        }else if(p.numKeys){for(i=1;i<=p.numKeys;i++){var s=H.snapshot(p,i);s.value=offsetValue(s.value,x,y,isShape);plan.keys.push(s);}}
        else plan.value=offsetValue(p.value,x,y,isShape);
        return plan;
    }
    function applyOffset(plan) {
        var p=plan.p;
        if(plan.baked){p.expression='';for(var k=p.numKeys;k>=1;k--)p.removeKey(k);for(k=0;k<plan.keys.length;k++)p.setValueAtTime(plan.keys[k].time,plan.keys[k].value);}
        else if(plan.keys.length){for(k=0;k<plan.keys.length;k++)H.writeKey(p,plan.keys[k],plan.keys[k].time,false,false);}
        else p.setValue(plan.value);
    }
    function resizePlan(c,r) {
        if(!c.numLayers)H.fail('The composition has no layers to crop.');
        var references=[],roots=[];
        for(var n=1;n<=c.numLayers;n++) {
            var sourceLayer=c.layer(n);
            if(sourceLayer.threeDLayer || sourceLayer instanceof CameraLayer || sourceLayer instanceof LightLayer) H.fail('Direct crop currently needs a 2D composition. No extra composition will be created.');
            if(!sourceLayer.parent) {
                var position=sourceLayer.property('ADBE Transform Group').property('ADBE Position'),offsets=[];
                if(position.isSeparationLeader && position.dimensionsSeparated) {
                    for(var axis=0;axis<2;axis++) {
                        var follower=position.getSeparationFollower(axis),delta=axis===0?r.x:r.y,record={p:follower,keys:[],value:null,baked:follower.expressionEnabled};
                        if(record.baked)for(var f=0;f<=Math.ceil(c.duration/c.frameDuration);f++){var time=Math.min(c.duration,f*c.frameDuration);record.keys.push({time:time,value:follower.valueAtTime(time,false)-delta});}
                        else if(follower.numKeys)for(var k=1;k<=follower.numKeys;k++){var snap=H.snapshot(follower,k);snap.value-=delta;record.keys.push(snap);}
                        else record.value=follower.value-delta;
                        offsets.push(record);
                    }
                }else offsets.push(offsetPlan(position,c,r.x,r.y,false));
                roots.push({layer:sourceLayer,locked:sourceLayer.locked,plans:offsets});
            }
        }
        for(var i=1;i<=app.project.numItems;i++){
            var owner=app.project.item(i);if(!(owner instanceof CompItem))continue;
            for(var j=1;j<=owner.numLayers;j++){
                var l=owner.layer(j);if(l.source!==c)continue;
                if(l.collapseTransformation)H.fail('Turn off Collapse Transformations on precomp instances before cropping.');
                var item={layer:l,locked:l.locked,plans:[]};
                item.plans.push(offsetPlan(l.property('ADBE Transform Group').property('ADBE Anchor Point'),owner,r.x,r.y,false));
                var masks=l.property('ADBE Mask Parade');
                for(var m=1;masks&&m<=masks.numProperties;m++)item.plans.push(offsetPlan(masks.property(m).property('ADBE Mask Shape'),owner,r.x,r.y,true));
                references.push(item);
            }
        }
        return {comp:c,rect:r,references:references,roots:roots};
    }
    function applyResize(plan) {
        var c=plan.comp,r=plan.rect,i;
        // Translate root layers only: children inherit the same translation.
        // Keep the original composition and all editable layers in place.
        for(i=0;i<plan.roots.length;i++){
            var root=plan.roots[i];root.layer.locked=false;
            try{for(var k=0;k<root.plans.length;k++)applyOffset(root.plans[k]);}finally{root.layer.locked=root.locked;}
        }
        c.width=r.width;c.height=r.height;
        for(i=0;i<plan.references.length;i++){
            var ref=plan.references[i];ref.layer.locked=false;
            try{for(var j=0;j<ref.plans.length;j++)applyOffset(ref.plans[j]);}finally{ref.layer.locked=ref.locked;}
        }
        return c;
    }
    function maskCrop(c,a) {
        var ls=H.layers(c);if(ls.length!==1||!(ls[0].source instanceof CompItem))H.fail('Select one masked precomp layer for Mask Crop.');
        var l=ls[0],masks=l.property('ADBE Mask Parade');if(!masks.numProperties)H.fail('Add a mask to the selected precomp first.');
        var selected=[],ps=l.selectedProperties,index=Number(a.maskIndex)||0;
        for(var i=0;i<ps.length;i++){var p=ps[i];while(p&&p.matchName!=='ADBE Mask Atom')p=p.parentProperty;if(p){var exists=false;for(var j=0;j<selected.length;j++)if(selected[j]===p.propertyIndex)exists=true;if(!exists)selected.push(p.propertyIndex);}}
        if(!index&&selected.length===1)index=selected[0];if(!index&&masks.numProperties===1)index=1;
        if(!index){var choices=[];for(i=1;i<=masks.numProperties;i++)choices.push({index:i,name:masks.property(i).name});return ok('Choose the mask to crop to.',{needsMaskChoice:true,masks:choices});}
        if(index<1||index>masks.numProperties)H.fail('That mask no longer exists.');
        var padding=a.paddingEnabled?Number(a.padding):0;if(!isFinite(padding))H.fail('Enter a numeric padding amount.');
        var mask=masks.property(index),r=rect(maskBounds(mask.property('ADBE Mask Shape').valueAtTime(c.time,false)),padding);
        var plan=resizePlan(l.source,r);applyResize(plan);
        if(a.deleteMask){var locked=l.locked;l.locked=false;try{l.property('ADBE Mask Parade').property(index).remove();}finally{l.locked=locked;}}
        return 'Mask Crop: '+r.width+' × '+r.height+'. Original composition and layers retained.';
    }
    function start(c,a) {
        var ts=selectedTargets(c,a.mode==='duration'),id='md'+(new Date().getTime())+'_'+(++serial),folder=new Folder(Folder.temp.fsName+'/MotionDock_'+id);
        for(var x=0;x<ts.length;x++)for(var y=0;y<ts.length;y++)if(x!==y)for(var z=1;z<=ts[x].comp.numLayers;z++)if(ts[x].comp.layer(z).source===ts[y].comp)H.fail('Crop nested source compositions separately to preserve their instance offsets.');
        if(!folder.create())H.fail('Could not create a temporary render folder. Enable scripts to write files in AE Preferences.');
        var total=0;
        for(var i=0;i<ts.length;i++){
            ts[i].width=ts[i].comp.width;ts[i].height=ts[i].comp.height;ts[i].frames=a.mode==='duration'?Math.ceil(ts[i].comp.duration/ts[i].comp.frameDuration):1;
            total+=ts[i].frames;
        }
        jobs[id]={targets:ts,folder:folder,target:0,frame:0,rendered:0,total:total,lastFile:null,mode:a.mode};
        return ok('Analysing '+total+' frame'+(total===1?'':'s')+'…',{jobId:id,totalFrames:total,targetCount:ts.length});
    }
    function job(id) { var j=jobs[id];if(!j)H.fail('The crop job expired. Start the crop again.');return j; }
    function renderFrame(c,a) {
        var j=job(a.jobId),target=j.targets[j.target];
        if(j.pending)return pollFrame(c,a);
        if(!target)return ok('Frame analysis complete.',{done:true});
        if(target.comp.width!==target.width||target.comp.height!==target.height)H.fail('Composition dimensions changed during analysis. Cancel and retry.');
        if(j.lastFile&&j.lastFile.exists)j.lastFile.remove();
        var file=new File(j.folder.fsName+'/frame.png'),time=j.mode==='duration'?Math.min(target.comp.duration-0.000001,j.frame*target.comp.frameDuration):target.time;
        j.pending={file:file,targetIndex:j.target,frameIndex:j.frame,width:target.width,height:target.height};
        target.comp.saveFrameToPng(time,file);
        return pollFrame(c,a);
    }
    function pollFrame(c,a) {
        var j=job(a.jobId),p=j.pending;
        if(!p)H.fail('No frame is being rendered.');
        var file=new File(p.file.fsName),ready=false;
        if(file.exists&&file.length>=32){file.encoding='BINARY';if(file.open('r')){file.seek(file.length-12,0);var tail=file.read(12);file.close();ready=tail.substr(4,4)==='IEND';}}
        if(!ready)return ok('Rendering frame '+(j.rendered+1)+' of '+j.total+'…',{pending:true,rendered:j.rendered,totalFrames:j.total});
        var target=j.targets[p.targetIndex];j.lastFile=file;var ti=p.targetIndex,fi=p.frameIndex;j.rendered++;j.frame++;j.pending=null;
        if(j.frame>=target.frames){j.target++;j.frame=0;}
        return ok('Analysed frame '+j.rendered+' of '+j.total+'.',{path:file.fsName,targetIndex:ti,frameIndex:fi,width:target.width,height:target.height,rendered:j.rendered,totalFrames:j.total,done:j.rendered===j.total});
    }
    function cleanup(id) {
        var j=jobs[id];if(!j)return;
        if(j.lastFile&&j.lastFile.exists)j.lastFile.remove();j.folder.remove();delete jobs[id];
    }
    function finish(c,a) {
        var j=job(a.jobId),plans=[],padding=a.paddingEnabled?Number(a.padding):0;
        if(!isFinite(padding))H.fail('Enter a numeric padding amount.');
        if(!a.bounds||a.bounds.length!==j.targets.length||j.rendered!==j.total)H.fail('Crop analysis is incomplete.');
        for(var i=0;i<j.targets.length;i++){
            var target=j.targets[i];if(target.comp.width!==target.width||target.comp.height!==target.height)H.fail('Composition dimensions changed during analysis.');
            plans.push(resizePlan(target.comp,rect(a.bounds[i],padding)));
        }
        for(i=0;i<plans.length;i++)applyResize(plans[i]);cleanup(a.jobId);
        return 'Cropped '+plans.length+' composition'+(plans.length===1?'':'s')+'; preserved artwork and updated all instances. Original composition and layers retained.';
    }
    function cancel(c,a){cleanup(a.jobId);return 'Crop cancelled; composition dimensions unchanged.';}
    return {actions:{maskCrop:maskCrop,autoCropStart:start,autoCropFrame:renderFrame,autoCropPoll:pollFrame,autoCropFinish:finish,autoCropCancel:cancel},test:{maskBounds:maskBounds,rect:rect,offsetValue:offsetValue}};
}());
