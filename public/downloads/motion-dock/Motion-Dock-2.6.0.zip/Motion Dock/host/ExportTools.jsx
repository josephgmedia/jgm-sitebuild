/* Stem export adapted from the supplied WAV script; render/import workflow
   follows the supplied Building Palette without its building-specific setup. */
var MotionDockExport=(function(){
 var H=MotionDock.helpers;
 function safe(s){return String(s).replace(/[<>:"\\|?*\x00-\x1f\/]/g,'_').replace(/[. ]+$/,'').substring(0,100)||'Export';}
 function folder(a){var f=new Folder(a.folder||'');if(!a.folder||!f.exists)H.fail('Choose an existing export folder first.');return f;}
 function child(parent,name){var f=new Folder(parent.fsName+'/'+name);if(!f.exists&&!f.create())H.fail('Could not create the export folder. Check folder access and AE scripting file permissions.');return f;}
 function unique(parent,name){var n=0,f;do{f=new Folder(parent.fsName+'/'+safe(name)+(n?'_'+n:''));n++;}while(f.exists);if(!f.create())H.fail('Could not create a new export folder.');return f;}
 function choose(c,a){var f=Folder.selectDialog(a.kind==='wav'?'Choose WAV stems folder':'Choose pre-render folder');return {ok:true,message:f?'Export folder selected.':'Folder selection cancelled.',folder:f?f.fsName:null};}
 function isWav(job,name){try{var om=settings(job,name),format=String(om.getSettings(GetSettingsFormat.STRING)['Format']);return /wav|wave/i.test(format);}catch(_){return false;}}
 function alphaSettings(job,name){var om=settings(job,name),s=om.getSettings(GetSettingsFormat.STRING);extension(String(s['Format']));var channels=String(s['Channels']).replace(/\s/g,'').toLowerCase();if(channels!=='rgb+alpha'){om.setSetting('Channels','RGB + Alpha');om=job.outputModule(1);s=om.getSettings(GetSettingsFormat.STRING);channels=String(s['Channels']).replace(/\s/g,'').toLowerCase();}if(channels!=='rgb+alpha')H.fail('This template cannot output RGB + Alpha.');if(!off(s['Resize'])||!off(s['Crop']))H.fail('Disable Resize and Crop in the Output Module template.');return om;}
 function info(c,a){var job=null,scratch=null;if(app.project.renderQueue.rendering)H.fail('Wait for the render to finish before refreshing templates.');try{if(!(c instanceof CompItem)){scratch=app.project.items.addComp('MD template inspection',16,16,1,1,24);c=scratch;}job=app.project.renderQueue.items.add(c);var available=job.outputModule(1).templates,templates=[];for(var i=0;i<available.length;i++)templates.push(String(available[i]));var out=[],wav=[],alpha=[];for(i=0;i<templates.length;i++)if(templates[i].indexOf('_HIDDEN')!==0){out.push(templates[i]);if(isWav(job,templates[i]))wav.push(templates[i]);try{alphaSettings(job,templates[i]);alpha.push(templates[i]);}catch(_){}}return {ok:true,message:alpha.length?'Output templates loaded.':'No compatible RGB + Alpha templates found. Save a QuickTime, AVI, PNG, EXR or TIFF Output Module template with Resize and Crop off, then refresh.',templates:out,wavTemplates:wav,alphaTemplates:alpha};}finally{if(job)job.remove();if(scratch)scratch.remove();}}
 function isolateQueue(rq,jobs){var queued=[];for(var i=1;i<=rq.numItems;i++){var q=rq.item(i),ours=false;for(var j=0;j<jobs.length;j++)if(q===jobs[j])ours=true;if(!ours&&q.status===RQItemStatus.QUEUED){queued.push(q);q.render=false;}}return queued;}
 function restoreQueue(queued){for(var i=0;i<queued.length;i++)try{queued[i].render=true;}catch(_){}}
 function remove(items){for(var i=items.length-1;i>=0;i--)try{items[i].remove();}catch(_){}}
 function off(v){return v===false||v===0||/^(false|off|0)$/i.test(String(v));}
 function settings(job,template){var om=job.outputModule(1);try{om.applyTemplate(template);}catch(e){H.fail('Output template not found: '+template+'. Refresh the template list.');}return job.outputModule(1);}
 function audioTemplate(job,wanted){if(wanted)return wanted;var templates=job.outputModule(1).templates,preferred=['WAV','WAV 48kHz','WAV 44.1kHz'];for(var p=0;p<preferred.length;p++)for(var i=0;i<templates.length;i++)if(templates[i]===preferred[p]&&isWav(job,templates[i]))return templates[i];for(i=0;i<templates.length;i++)if(templates[i].indexOf('_HIDDEN')!==0&&isWav(job,templates[i]))return templates[i];H.fail('Save a WAV Output Module template in AE, then refresh the template list.');}
 function stems(c,a){
  if(!a.withLevels&&!a.raw)H.fail('Choose With levels, Flat levels, or both.');
  var rq=app.project.renderQueue;if(rq.rendering)H.fail('Wait for the current render to finish.');
  var parent=folder(a),selected=c.selectedLayers,targets=[],i,j;
  for(i=1;i<=c.numLayers;i++){var l=c.layer(i),included=!a.selectedOnly;if(a.selectedOnly)for(j=0;j<selected.length;j++)if(selected[j]===l)included=true;if(included&&l.hasAudio&&(a.includeMuted||l.audioEnabled))targets.push({index:i,name:l.name});}
  if(!targets.length)H.fail('No matching audio layers. Check selection and Include muted.');
  var out=null,jobs=[],temps=[],queued=[],files=[],variants=[];if(a.withLevels)variants.push({name:'with_levels',raw:false});if(a.raw)variants.push({name:'flat_levels',raw:true});
  try{
   // Validate template before creating an output folder or all temporary comps.
   var probe=rq.items.add(c),template;try{template=audioTemplate(probe,a.template);var om=settings(probe,template),s=om.getSettings(GetSettingsFormat.STRING);if(!/wav|wave/i.test(String(s['Format'])))H.fail('The audio template must use WAV format.');if(off(s['Audio Output']))H.fail('Enable Audio Output in the WAV template.');}finally{probe.remove();}
   out=unique(parent,c.name+'_stems');
   for(i=0;i<targets.length;i++)for(j=0;j<variants.length;j++){
    var target=targets[i],variant=variants[j],tmp=c.duplicate();temps.push(tmp);tmp.displayStartTime=0;tmp.name='MD stem · '+target.name;
    for(var k=1;k<=tmp.numLayers;k++){var layer=tmp.layer(k);layer.locked=false;layer.solo=false;layer.enabled=false;if(layer.hasAudio)layer.audioEnabled=k===target.index;}
    var stem=tmp.layer(target.index);if(variant.raw){var levels=stem.property('ADBE Audio Group').property('ADBE Audio Levels');levels.expression='';while(levels.numKeys)levels.removeKey(levels.numKeys);levels.setValue([0,0]);}
    var job=rq.items.add(tmp);jobs.push(job);var module=settings(job,template);var file=new File(child(out,variant.name).fsName+'/L'+target.index+'_'+safe(target.name)+(variant.raw?'_FLAT':'_LEVELS')+'.wav');module.file=file;module.postRenderAction=PostRenderAction.NONE;files.push(file);
    job.timeSpanStart=0;job.timeSpanDuration=c.duration;job.skipFrames=0;job.render=true;
   }
   queued=isolateQueue(rq,jobs);rq.showWindow(true);rq.render();
   for(i=0;i<jobs.length;i++)if(jobs[i].status!==RQItemStatus.DONE||!files[i].exists||files[i].length<44)H.fail('Stem render stopped or failed. Original layers are unchanged. Completed files remain in '+out.fsName);
   return 'Exported '+files.length+' WAV stems, aligned to comp start: '+out.fsName;
  }finally{restoreQueue(queued);remove(jobs);remove(temps);}
 }
 function extension(format){if(/openexr|exr/i.test(format))return 'exr';if(/png/i.test(format))return 'png';if(/tiff/i.test(format))return 'tif';if(/quicktime/i.test(format))return 'mov';if(/avi/i.test(format))return 'avi';H.fail('Use a QuickTime, AVI, EXR, PNG or TIFF template with RGB + Alpha.');}
 function prerender(c,a){
  var ls=H.layers(c),rq=app.project.renderQueue;if(rq.rendering)H.fail('Wait for the current render to finish.');var parent=folder(a),indices=[],ids=[],i,j,top=ls[0],count=0;
  for(i=0;i<ls.length;i++){var l=ls[i];if(l.locked)H.fail('Unlock the selected layers before pre-rendering.');if(l.isTrackMatte)H.fail('Select the artwork using a matte; its matte is included automatically.');if(l.adjustmentLayer||l.blendingMode!==BlendingMode.NORMAL||l.guideLayer)H.fail('Pre-render ordinary artwork with Normal blending. Adjustment/guide layers and non-Normal blending need a separate compositing check.');if(!l.enabled)H.fail('Select enabled artwork layers.');indices.push(l.index);ids.push(l.id);if(l.index<top.index)top=l;count++;}
  // Interleaved unselected artwork cannot be replaced by one flat layer faithfully.
  var min=top.index,max=min;for(i=0;i<indices.length;i++)max=Math.max(max,indices[i]);
  for(i=min;i<=max;i++){var between=c.layer(i),hit=false;for(j=0;j<indices.length;j++)if(indices[j]===i)hit=true;if(!hit&&between.enabled&&!between.nullLayer&&!between.isTrackMatte)H.fail('Select consecutive artwork layers so the pre-render keeps their stacking order.');}
  var anySolo=false,selectedSolo=false;for(i=1;i<=c.numLayers;i++)if(c.layer(i).solo)anySolo=true;for(i=0;i<ls.length;i++)if(ls[i].solo)selectedSolo=true;if(anySolo&&!selectedSolo)H.fail('Select the soloed artwork, or turn off Solo before pre-rendering.');
  var start=a.range==='full'?0:c.workAreaStart,duration=a.range==='full'?c.duration:c.workAreaDuration;
  if(duration<=0)H.fail('The render range is empty.');
  // A partial replacement would require splitting originals into before/after sections.
  for(i=0;i<ls.length;i++)if(ls[i].inPoint<start-.000001||ls[i].outPoint>start+duration+.000001)H.fail('The render range must cover the selected layers before they can be disabled. Use Full composition or trim their in/out points to the work area.');
  var tmp=null,job=null,footage=null,replacement=null,queued=[],out=null,completed=false,undoStarted=false;
  try{
   tmp=c.duplicate();tmp.displayStartTime=0;tmp.name='MD pre-render · '+c.name;tmp.resolutionFactor=[1,1];
   var included={};for(i=0;i<indices.length;i++)included[indices[i]]=true;
   for(i=0;i<indices.length;i++){var source=tmp.layer(indices[i]);while(source.hasTrackMatte){source=source.trackMatteLayer;if(included[source.index])break;included[source.index]=true;}}
   for(i=1;i<=tmp.numLayers;i++){var layer=tmp.layer(i);layer.locked=false;var visible=!!included[i]&&(!anySolo||layer.solo||layer.isTrackMatte);layer.solo=false;if(layer instanceof CameraLayer||layer instanceof LightLayer)continue;layer.enabled=visible;if(layer.hasAudio)layer.audioEnabled=false;}
   job=rq.items.add(tmp);var om=alphaSettings(job,a.template),s=om.getSettings(GetSettingsFormat.STRING),channels=String(s['Channels']).replace(/\s/g,'').toLowerCase();
   if(channels!=='rgb+alpha')H.fail('Save/select an Output Module template using RGB + Alpha for the replacement.');
   if(!off(s['Resize'])||!off(s['Crop']))H.fail('Disable Resize and Crop in the Output Module template.');
   var ext=extension(String(s['Format'])),sequence=/^(exr|png|tif)$/.test(ext);out=unique(parent,c.name+'_prerender');var base=safe(c.name)+'_prerender';
   om.file=new File(out.fsName+'/'+base+(sequence?'_[#####]':'')+'.'+ext);om.postRenderAction=PostRenderAction.NONE;
   job.timeSpanStart=start;job.timeSpanDuration=duration;job.skipFrames=0;job.setSetting('Quality','Best');job.setSetting('Resolution','Full');job.render=true;
   queued=isolateQueue(rq,[job]);rq.showWindow(true);rq.render();if(job.status!==RQItemStatus.DONE)H.fail('Render stopped or failed. Originals remain enabled.');
   var files=out.getFiles(function(f){return f instanceof File&&File.decode(f.name).indexOf(base)===0&&new RegExp('\\.'+ext+'$','i').test(f.name);});files.sort(function(a,b){return a.name<b.name?-1:1;});
   var expected=Math.round(duration*c.frameRate);if(!files.length||(sequence&&files.length!==expected))H.fail('Rendered output is missing or incomplete. Originals remain enabled.');
   app.beginUndoGroup('Motion Dock · Pre-render replacement');undoStarted=true;
   var options=new ImportOptions(files[0]);options.sequence=sequence&&files.length>1;options.forceAlphabetical=false;footage=app.project.importFile(options);footage.name=base;
   if(sequence&&files.length>1)footage.mainSource.conformFrameRate=c.frameRate;
   if(footage.width!==c.width||footage.height!==c.height)H.fail('Rendered dimensions differ from the composition. Originals remain enabled.');
   replacement=c.layers.add(footage);replacement.name=base;replacement.startTime=start;replacement.inPoint=start;replacement.outPoint=start+duration;replacement.moveBefore(top);replacement.solo=selectedSolo;replacement.comment='Motion Dock pre-render. Original layer IDs: '+ids.join(',')+'. Re-enable originals and re-render after changes.';
   // Audio remains live on originals; this is a visual pre-render.
   if(replacement.hasAudio)replacement.audioEnabled=false;
   for(i=0;i<ls.length;i++){ls[i].enabled=false;ls[i].shy=true;ls[i].selected=false;}
   c.hideShyLayers=true;replacement.selected=true;completed=true;
   return 'Pre-render imported; '+count+' original layers disabled and shy. Audio remains live. Output: '+out.fsName;
  }finally{restoreQueue(queued);if(!completed){if(replacement)try{replacement.remove();}catch(_){}if(footage)try{footage.remove();}catch(_){}}if(job)try{job.remove();}catch(_){}if(tmp)try{tmp.remove();}catch(_){}if(undoStarted)app.endUndoGroup();}
 }
 return {actions:{chooseExportFolder:choose,exportInfo:info,exportStems:stems,prerender:prerender}};
}());
