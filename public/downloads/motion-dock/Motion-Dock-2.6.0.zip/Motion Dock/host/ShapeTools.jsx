var MotionDockShapes = (function () {
    var H = MotionDock.helpers;
    function root(l) { return l.property('ADBE Root Vectors Group'); }
    function geometry(p) { return p.propertyType !== PropertyType.PROPERTY && (p.matchName === 'ADBE Vector Group' || /^ADBE Vector Shape - /.test(p.matchName)); }
    function contents(p) { return p.matchName === 'ADBE Vector Group' ? p.property('ADBE Vectors Group') : null; }
    function at(l, path) { var p = root(l); for (var i = 0; i < path.length; i++) p = p.property(path[i]); return p; }
    function pathOf(p) { var path = []; while (p && p.matchName !== 'ADBE Root Vectors Group') { path.unshift(p.propertyIndex); p = p.parentProperty; } return p ? path : null; }
    function prefix(a, b) { if (a.length > b.length) return false; for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false; return true; }
    function hasGeometry(p) { for (var i = 1; i <= p.numProperties; i++) { var q = p.property(i); if (/^ADBE Vector Shape/.test(q.matchName)) return true; if (q.matchName === 'ADBE Vector Group' && hasGeometry(contents(q))) return true; } return false; }
    function targets(c, wholeLayers) {
        var ls = H.layers(c), plans = [], any = false, i, j;
        H.unlocked(ls);
        for (i = 0; i < ls.length; i++) {
            var l = ls[i], r = root(l), found = [];
            if (!r) H.fail('Select shape layers only.');
            if (!wholeLayers) {
                var selected = l.selectedProperties;
                for (j = 0; j < selected.length; j++) {
                    var p = selected[j];
                    while (p && p.matchName !== 'ADBE Root Vectors Group' && !geometry(p)) p = p.parentProperty;
                    if (!p || !geometry(p)) continue;
                    var path = pathOf(p); if (!path) continue;
                    var skip = false;
                    for (var k = found.length - 1; k >= 0; k--) { if (prefix(found[k], path)) skip = true; else if (prefix(path, found[k])) found.splice(k, 1); }
                    if (!skip) found.push(path);
                }
            }
            if (found.length) any = true;
            plans.push({ layer: l, paths: found });
        }
        for (i = plans.length - 1; i >= 0; i--) {
            if (any && !plans[i].paths.length) { plans.splice(i, 1); continue; }
            if (!plans[i].paths.length) { r = root(plans[i].layer); for (j = 1; j <= r.numProperties; j++) if (geometry(r.property(j))) plans[i].paths.push([j]); }
            if (!plans[i].paths.length) H.fail('No shape paths or groups were found.');
        }
        return plans;
    }
    function prune(p, paths) {
        for (var i = p.numProperties; i >= 1; i--) {
            var q = p.property(i); if (!geometry(q)) continue;
            var matching = [], keepWhole = false;
            for (var j = 0; j < paths.length; j++) if (paths[j][0] === i) { if (paths[j].length === 1) keepWhole = true; else matching.push(paths[j]); }
            if (keepWhole) continue;
            if (!matching.length) { q.remove(); continue; }
            var child = contents(q); if (!child) H.fail('Cannot extract this shape selection.');
            var tails = [];
            for (j = 0; j < matching.length; j++) { if (matching[j][1] !== child.propertyIndex) H.fail('Select shape contents rather than a transform control.'); tails.push(matching[j].slice(2)); }
            prune(child, tails);
        }
    }
    function sortDescending(a, b) { var n = Math.min(a.length, b.length); for (var i = 0; i < n; i++) if (a[i] !== b[i]) return b[i] - a[i]; return b.length - a.length; }
    function mayRemoveLayers(c, plans, keep) {
        if (keep) return;
        for (var i = 0; i < plans.length; i++) for (var j = 1; j <= c.numLayers; j++) if (c.layer(j).parent === plans[i].layer) {
            // Only refuse when no source geometry would remain. Partial extraction is safe.
            var paths = plans[i].paths, r = root(plans[i].layer), all = true;
            for (var k = 1; k <= r.numProperties; k++) if (geometry(r.property(k))) { var hit = false; for (var n = 0; n < paths.length; n++) if (paths[n].length === 1 && paths[n][0] === k) hit = true; if (!hit) all = false; }
            if (all) H.fail('A source is a parent layer. Alt-click to retain it and its child animation.');
        }
    }
    function removeSources(plans) {
        for (var i = 0; i < plans.length; i++) {
            var paths = plans[i].paths.slice(0); paths.sort(sortDescending);
            for (var j = 0; j < paths.length; j++) at(plans[i].layer, paths[j]).remove();
            if (!hasGeometry(root(plans[i].layer))) {
                var c = plans[i].layer.containingComp, children = false;
                for (var k = 1; k <= c.numLayers; k++) if (c.layer(k).parent === plans[i].layer) children = true;
                if (!children) plans[i].layer.remove();
            }
        }
    }
    function selectOnly(c, ls) { var old = c.selectedLayers; for (var i = 0; i < old.length; i++) old[i].selected = false; for (i = 0; i < ls.length; i++) ls[i].selected = true; }
    function explode(c, a) {
        var plans = targets(c, false), made = [], i, j;
        mayRemoveLayers(c, plans, a.alt);
        try {
            for (i = 0; i < plans.length; i++) for (j = 0; j < plans[i].paths.length; j++) {
                var l = plans[i].layer, path = plans[i].paths[j], name = at(l, path).name;
                var d = l.duplicate(); made.push(d);
                prune(root(d), [path]); d.name = l.name + ' · ' + name;
            }
        } catch (e) { for (i = made.length - 1; i >= 0; i--) made[i].remove(); throw e; }
        if (!a.alt) removeSources(plans);
        selectOnly(c, made);
        return (a.alt ? 'Extracted ' : 'Exploded ') + made.length + ' selected shapes' + (a.alt ? '; originals retained.' : '; extracted sources removed.');
    }
    function samples(p, c) {
        var out = { value: null, keys: [], baked: false }, i;
        var bake = (p.canSetExpression && p.expressionEnabled) || (p.isSeparationLeader && p.dimensionsSeparated);
        if (bake) {
            out.baked = true;
            for (i = 0; i <= Math.ceil(c.duration / c.frameDuration); i++) { var time = Math.min(c.duration, i * c.frameDuration); out.keys.push({ time: time, value: p.valueAtTime(time, false) }); }
        } else if (p.numKeys) { for (i = 1; i <= p.numKeys; i++) out.keys.push(H.snapshot(p, i)); }
        else out.value = p.value;
        return out;
    }
    function put(p, data) {
        function fit(value) { var target = p.value; return value instanceof Array && target instanceof Array && value.length !== target.length ? value.slice(0, target.length) : value; }
        if (!data.keys.length) { p.setValue(fit(data.value)); return; }
        for (var i = 0; i < data.keys.length; i++) {
            var s = data.keys[i]; p.setValueAtTime(s.time, fit(s.value)); var k = p.nearestKeyIndex(s.time);
            if (!data.baked) {
                p.setInterpolationTypeAtKey(k, s.inType, s.outType);
                if (s.inEase) { var ins = [], outs = [], count = p.keyInTemporalEase(k).length; for (var n = 0; n < count; n++) { ins.push(s.inEase[Math.min(n, s.inEase.length - 1)]); outs.push(s.outEase[Math.min(n, s.outEase.length - 1)]); } p.setTemporalEaseAtKey(k, ins, outs); p.setTemporalContinuousAtKey(k, s.cont); p.setTemporalAutoBezierAtKey(k, s.auto); }
                if (p.isSpatial && s.inTangent) { p.setSpatialTangentsAtKey(k, fit(s.inTangent), fit(s.outTangent)); p.setSpatialContinuousAtKey(k, s.sCont); p.setSpatialAutoBezierAtKey(k, s.sAuto); }
            }
        }
    }
    function capture(p) {
        var node = { match: p.matchName, name: p.name, leaf: p.propertyType === PropertyType.PROPERTY };
        if (p.canSetEnabled) node.enabled = p.enabled;
        if (node.leaf) {
            if (!p.isModified && !p.numKeys && !(p.canSetExpression && p.expressionEnabled)) { node.skip = true; return node; }
            if (p.propertyValueType === PropertyValueType.CUSTOM_VALUE) H.fail('NATIVE_COPY_REQUIRED');
            if (p.propertyValueType === PropertyValueType.NO_VALUE) { node.skip = true; return node; }
            node.data = { value: null, keys: [], baked: false };
            for (var k = 1; k <= p.numKeys; k++) node.data.keys.push(H.snapshot(p, k));
            if (!p.numKeys) node.data.value = p.value;
            if (p.canSetExpression && p.expressionEnabled) H.fail('Bake shape expressions before transfer.');
        } else { node.children = []; for (var i = 1; i <= p.numProperties; i++) node.children.push(capture(p.property(i))); }
        return node;
    }
    function restore(parent, node) {
        if (node.skip) return;
        var p = parent.canAddProperty && parent.canAddProperty(node.match) ? parent.addProperty(node.match) : parent.property(node.match);
        if (!p) H.fail('Cannot recreate ' + node.name + '.');
        try { p.name = node.name; } catch (_) {}
        if (node.enabled !== undefined && p.canSetEnabled) p.enabled = node.enabled;
        if (node.leaf) { try { put(p, node.data); } catch (e) { H.fail('Shape property ' + node.match + ' (' + node.name + '): ' + e.message); } }
        else { var index = p.propertyIndex; for (var i = 0; i < node.children.length; i++) restore(parent.property(index), node.children[i]); }
    }
    function clearSelection(c) {
        function clear(p) { try { p.selected = false; } catch (_) {} if (p.propertyType !== PropertyType.PROPERTY) for (var k = 1; k <= p.numProperties; k++) clear(p.property(k)); }
        for (var i = 1; i <= c.numLayers; i++) { clear(c.layer(i)); c.layer(i).selected = false; }
    }
    function transfer(c, source, target, targetPath) {
        var r = root(source), nodes = [], nativeCopy = false, i;
        try { for (i = 1; i <= r.numProperties; i++) nodes.push(capture(r.property(i))); } catch (e) { if (String(e.message) === 'NATIVE_COPY_REQUIRED') nativeCopy = true; else throw e; }
        if (!nativeCopy) { for (i = 0; i < nodes.length; i++) restore(at(target, targetPath), nodes[i]); return; }
        // Native property transfer preserves gradient/custom shape data inaccessible to JSX.
        c.openInViewer(); clearSelection(c); source.selected = true;
        for (i = 1; i <= r.numProperties; i++) r.property(i).selected = true;
        app.executeCommand(app.findMenuCommandId('Copy') || 19);
        clearSelection(c); target.selected = true; at(target, targetPath).selected = true;
        var oldCount = at(target, targetPath).numProperties, oldLayers = c.numLayers, known = [];
        for (i = 1; i <= c.numLayers; i++) known.push(c.layer(i).id);
        app.executeCommand(app.findMenuCommandId('Paste') || 20);
        if (c.numLayers !== oldLayers || at(target, targetPath).numProperties !== oldCount + r.numProperties) {
            for (i = c.numLayers; i >= 1; i--) { var existing = false; for (var n = 0; n < known.length; n++) if (c.layer(i).id === known[n]) existing = true; if (!existing) c.layer(i).remove(); }
            H.fail('After Effects could not transfer this custom/gradient group. Sources were retained.');
        }
    }
    function expressionBakePlan(l, c) {
        var out = [];
        H.walk(root(l), function (p) { if (p.canSetExpression && p.expressionEnabled) out.push({ path: pathOf(p), data: samples(p, c) }); });
        return out;
    }
    function applyBakes(l, plans) {
        for (var i = 0; i < plans.length; i++) { var p = at(l, plans[i].path); p.expression = ''; for (var k = p.numKeys; k >= 1; k--) p.removeKey(k); put(p, plans[i].data); }
    }
    function chainPlan(l, c) {
        var chain = [], p = l;
        while (p) {
            if (p.threeDLayer || p.autoOrient !== AutoOrientType.NO_AUTO_ORIENT) H.fail('Merge supports 2D shapes without auto-orientation.');
            var t = p.property('ADBE Transform Group'), record = { name: p.name, data: [] };
            var names = ['ADBE Anchor Point','ADBE Position','ADBE Scale','ADBE Rotate Z'];
            for (var i = 0; i < names.length; i++) record.data.push(samples(t.property(names[i]), c));
            if (p === l) record.opacity = samples(t.property('ADBE Opacity'), c);
            chain.unshift(record); p = p.parent;
        }
        return chain;
    }
    function wrapper(l, parentPath, name) {
        var parent = at(l, parentPath), g = parent.addProperty('ADBE Vector Group'); g.name = name;
        return parentPath.concat([g.propertyIndex]);
    }
    function merge(c, a) {
        // Alt explicitly merges complete selected layers; normal click honours selected contents.
        var plans = targets(c, !!a.alt), i, j, total = 0, prepared = [], temp = [], output = null;
        plans.sort(function (x,y) { return x.layer.index - y.layer.index; });
        for (i = 0; i < plans.length; i++) total += plans[i].paths.length;
        if (!a.alt && total < 2) H.fail('Select at least two shapes or shape layers to merge.');
        mayRemoveLayers(c, plans, a.alt);
        for (i = 0; i < plans.length; i++) {
            var l = plans[i].layer;
            if (l.hasTrackMatte || l.isTrackMatte || l.adjustmentLayer || l.blendingMode !== BlendingMode.NORMAL || l.property('ADBE Effect Parade').numProperties || l.property('ADBE Mask Parade').numProperties) H.fail('Merge needs ordinary 2D shape layers without layer-level effects, masks, mattes, or non-normal blending. Their compositing cannot be retained as shape groups.');
            if (l.motionBlur !== plans[0].layer.motionBlur) H.fail('Match source motion-blur switches before merging.');
            prepared.push({ chain: chainPlan(l, c), bakes: expressionBakePlan(l, c) });
        }
        try {
            output = c.layers.addShape(); output.name = 'Merged shapes'; output.moveBefore(plans[0].layer);
            output.motionBlur = plans[0].layer.motionBlur;
            var anySelectedSolo = false;
            for (i = 0; i < plans.length; i++) if (plans[i].layer.solo) anySelectedSolo = true;
            output.solo = anySelectedSolo;
            var ot = output.property('ADBE Transform Group'); ot.property('ADBE Position').setValue([0,0]); ot.property('ADBE Anchor Point').setValue([0,0]);
            for (i = 0; i < plans.length; i++) {
                l = plans[i].layer;
                var d = l.duplicate(); temp.push(d); applyBakes(d, prepared[i].bakes); prune(root(d), plans[i].paths);
                var visibility = wrapper(output, [], l.name), visibilityGroup = at(output, visibility), visibleOpacity = visibilityGroup.property('ADBE Vector Transform Group').property('ADBE Vector Group Opacity');
                visibleOpacity.expression = l.enabled && (!anySelectedSolo || l.solo) ? 'time >= ' + l.inPoint + ' && time < ' + l.outPoint + ' ? 100 : 0' : '0';
                var parentPath = visibility.concat([visibilityGroup.property('ADBE Vectors Group').propertyIndex]);
                for (j = 0; j < prepared[i].chain.length; j++) {
                    var record = prepared[i].chain[j], path = wrapper(output, parentPath, record.name), group = at(output, path), transform = group.property('ADBE Vector Transform Group');
                    var destNames = ['ADBE Vector Anchor','ADBE Vector Position','ADBE Vector Scale','ADBE Vector Rotation'];
                    for (var k = 0; k < destNames.length; k++) put(transform.property(destNames[k]), record.data[k]);
                    if (record.opacity) put(transform.property('ADBE Vector Group Opacity'), record.opacity);
                    parentPath = path.concat([group.property('ADBE Vectors Group').propertyIndex]);
                }
                transfer(c, d, output, parentPath);
            }
        } catch (e) { for (i = temp.length-1; i >= 0; i--) temp[i].remove(); if (output) output.remove(); throw e; }
        for (i = temp.length-1; i >= 0; i--) temp[i].remove();
        if (!a.alt) removeSources(plans);
        selectOnly(c, [output]);
        return 'Merged ' + total + ' shape groups' + (a.alt ? '; original layers retained.' : '; merged sources removed.');
    }
    return { actions: { explode: explode, merge: merge }, test: { targets: targets, prune: prune, pathOf: pathOf, prefix: prefix } };
}());
