/* Independent Motion Dock tools. No third-party recovered source is included. */
var MotionDockExtras = (function () {
    var dir = File($.fileName).parent.fsName;
    $.evalFile(new File(dir + '/AnimationTools.jsx'));
    $.evalFile(new File(dir + '/ShapeTools.jsx'));
    $.evalFile(new File(dir + '/CropTools.jsx'));
    $.evalFile(new File(dir + '/ControllerTools.jsx'));
    $.evalFile(new File(dir + '/PruneTools.jsx'));
    $.evalFile(new File(dir + '/ExportTools.jsx'));
    $.evalFile(new File(dir + '/ROIPatchTools.jsx'));
    $.evalFile(new File(dir + '/PropertyControls.jsx'));
    $.evalFile(new File(dir + '/ExpressionPresets.jsx'));
    $.evalFile(new File(dir + '/CounterTools.jsx'));
    var actions = {}, modules = [MotionDockROI, MotionDockPresets, MotionDockPropertyControls, MotionDockAnimation, MotionDockShapes, MotionDockCrops, MotionDockControllers, MotionDockPrune, MotionDockExport];
    for (var i = 0; i < modules.length; i++) for (var key in modules[i].actions) if (modules[i].actions.hasOwnProperty(key)) actions[key] = modules[i].actions[key];
    return { actions: actions, clipboardCount: MotionDockAnimation.clipboardCount };
}());
