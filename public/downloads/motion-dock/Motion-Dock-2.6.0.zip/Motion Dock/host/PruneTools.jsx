/* Geometry pruning based on the supplied script, with corrected transform order
   and conservative skips for animation and geometry-changing operators. */
var MotionDockPrune=(function(){
 var H=MotionDock.helpers;
 function ident(){return [1,0,0,1,0,0];}
 function mul(a,b){return [a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];}
 function transform(m,p){return [m[0]*p[0]+m[2]*p[1]+m[4],m[1]*p[0]+m[3]*p[1]+m[5]];}
 function geometry(p){return /^ADBE Vector Shape - /.test(p.matchName);}
 function moving(p){var found=false;H.walk(p,function(q){if(q.numKeys || (q.canSetExpression&&q.expressionEnabled))found=true;});return found;}
 function groupMatrix(g){var t=g.property('ADBE Vector Transform Group'),a=t.property('ADBE Vector Anchor').value,p=t.property('ADBE Vector Position').value,s=t.property('ADBE Vector Scale').value,r=t.property('ADBE Vector Rotation').value*Math.PI/180;
  var cosine=Math.cos(r),sine=Math.sin(r);return mul([1,0,0,1,p[0],p[1]],mul([cosine,sine,-sine,cosine,0,0],mul([s[0]/100,0,0,s[1]/100,0,0],[1,0,0,1,-a[0],-a[1]])));}
 function unsupported(contents){
  for(var i=1;i<=contents.numProperties;i++){var p=contents.property(i),mn=p.matchName;
   if(mn==='ADBE Vector Group'){var t=p.property('ADBE Vector Transform Group');if(moving(t)||Math.abs(t.property('ADBE Vector Skew').value)>.00001||unsupported(p.property('ADBE Vectors Group')))return true;}
   else if(geometry(p)){if(p.matchName==='ADBE Vector Shape - Star'||moving(p))return true;}
   else if(mn==='ADBE Vector Graphic - G-Stroke')return true;
   else if(mn==='ADBE Vector Graphic - Stroke'){if(moving(p))return true;}
   else if(mn.indexOf('ADBE Vector Filter')===0 && mn!=='ADBE Vector Filter - Trim' && mn!=='ADBE Vector Filter - Merge' && mn!=='ADBE Vector Filter - RC')return true;
  }return false;
 }
 function points(p){var mn=p.matchName,out=[],i;
  if(mn==='ADBE Vector Shape - Group'){var shape=p.property('ADBE Vector Shape').value;for(i=0;i<shape.vertices.length;i++){var v=shape.vertices[i];out.push(v);out.push([v[0]+shape.inTangents[i][0],v[1]+shape.inTangents[i][1]]);out.push([v[0]+shape.outTangents[i][0],v[1]+shape.outTangents[i][1]]);}return out;}
  var size,pos,radius;
  if(mn==='ADBE Vector Shape - Rect'){size=p.property('ADBE Vector Rect Size').value;pos=p.property('ADBE Vector Rect Position').value;}
  else if(mn==='ADBE Vector Shape - Ellipse'){size=p.property('ADBE Vector Ellipse Size').value;pos=p.property('ADBE Vector Ellipse Position').value;}
  else if(mn==='ADBE Vector Shape - Star')return null;
  else return null;
  return [[pos[0]-size[0]/2,pos[1]-size[1]/2],[pos[0]+size[0]/2,pos[1]-size[1]/2],[pos[0]-size[0]/2,pos[1]+size[1]/2],[pos[0]+size[0]/2,pos[1]+size[1]/2]];
 }
 function stroke(contents){var width=0;for(var i=1;i<=contents.numProperties;i++){var p=contents.property(i);if(p.matchName==='ADBE Vector Graphic - Stroke'){var miter=4;try{miter=Math.max(1,p.property('ADBE Vector Stroke Miter Limit').value);}catch(_){}width=Math.max(width,p.property('ADBE Vector Stroke Width').value*.5*miter);}}return width;}
 function outside(l,ps,m,pad){if(!ps||!ps.length)return false;var b=[Infinity,Infinity,-Infinity,-Infinity];for(var i=0;i<ps.length;i++){var v=transform(m,ps[i]);var corners=[[v[0]-pad,v[1]-pad],[v[0]+pad,v[1]-pad],[v[0]-pad,v[1]+pad],[v[0]+pad,v[1]+pad]];for(var j=0;j<4;j++){var q=l.sourcePointToComp(corners[j]);b[0]=Math.min(b[0],q[0]);b[1]=Math.min(b[1],q[1]);b[2]=Math.max(b[2],q[0]);b[3]=Math.max(b[3],q[1]);}}var c=l.containingComp;return b[2]<-1||b[0]>c.width+1||b[3]<-1||b[1]>c.height+1;}
 function hasGeometry(c){for(var i=1;i<=c.numProperties;i++){var p=c.property(i);if(geometry(p))return true;if(p.matchName==='ADBE Vector Group'&&hasGeometry(p.property('ADBE Vectors Group')))return true;}return false;}
 function prune(l,contents,m,inherited,stats){var expansion=inherited+stroke(contents)*Math.max(Math.abs(m[0])+Math.abs(m[2]),Math.abs(m[1])+Math.abs(m[3]));for(var i=contents.numProperties;i>=1;i--){var p=contents.property(i);if(p.matchName==='ADBE Vector Group'){var index=p.propertyIndex,child=p.property('ADBE Vectors Group');prune(l,child,mul(m,groupMatrix(p)),expansion,stats);p=contents.property(index);if(!hasGeometry(p.property('ADBE Vectors Group'))){p.remove();stats.groups++;}}
  else if(geometry(p)&&outside(l,points(p),m,expansion)){p.remove();stats.paths++;}}
 }
 function run(c,a){var selected=c.selectedLayers,ls=[],stats={groups:0,paths:0,skipped:0},i;
  if(selected.length){for(i=0;i<selected.length;i++)if(selected[i].matchName==='ADBE Vector Layer')ls.push(selected[i]);if(!ls.length)H.fail('Select shape layers, or deselect layers to prune all shapes in this composition.');}
  else for(i=1;i<=c.numLayers;i++)if(c.layer(i).matchName==='ADBE Vector Layer')ls.push(c.layer(i));
  for(i=0;i<ls.length;i++){var l=ls[i],ancestor=l,unsafe=l.locked||l.threeDLayer,root=l.property('ADBE Root Vectors Group');while(ancestor){if(ancestor.threeDLayer||moving(ancestor.property('ADBE Transform Group'))||ancestor.autoOrient!==AutoOrientType.NO_AUTO_ORIENT)unsafe=true;ancestor=ancestor.parent;}
   var fx=l.property('ADBE Effect Parade');for(var j=1;j<=fx.numProperties;j++){var effect=fx.property(j);if(effect.enabled && effect.matchName!=='ADBE Fill' && !/Control$/.test(effect.matchName))unsafe=true;}
   if(unsafe||unsupported(root)){stats.skipped++;continue;}prune(l,root,ident(),0,stats);
  }
  return 'Pruned '+stats.paths+' outside paths and '+stats.groups+' empty groups.'+(stats.skipped?' Kept '+stats.skipped+' layers with animation, 3D, locks or unsupported geometry/effects.':'')+' Empty layers retained as controllers.';
 }
 return {actions:{prune:run},test:{matrix:groupMatrix,transform:transform}};
}());
