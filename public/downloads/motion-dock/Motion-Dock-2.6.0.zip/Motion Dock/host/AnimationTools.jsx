var MotionDockAnimation = (function () {
    var H = MotionDock.helpers, clipboard = [];
    function result(message, fields) { var r = fields || {}; r.ok = true; r.message = message; return r; }
    function copyKeys(c) {
        var ps = H.keyProps(c), next = [];
        for (var i = 0; i < ps.length; i++) {
            var p = ps[i].p, keys = p.selectedKeys;
            for (var j = 0; j < keys.length; j++) {
                var k = keys[j];
                if (!p.isInterpolationTypeValid(KeyframeInterpolationType.BEZIER)) H.fail('Copy numeric, colour, or shape keyframes.');
                var s = H.snapshot(p, k);
                s.type = p.propertyValueType; s.spatial = p.isSpatial;
                s.previous = k > 1 ? { value: p.keyValue(k - 1), time: p.keyTime(k - 1) } : null;
                s.next = k < p.numKeys ? { value: p.keyValue(k + 1), time: p.keyTime(k + 1) } : null;
                next.push(s);
            }
        }
        if (!next.length) H.fail('Select keyframes to copy first.');
        clipboard = next;
        return result('Copied ' + clipboard.length + ' keyframes.', { clipboardCount: clipboard.length });
    }
    function component(v, i) { return v instanceof Array ? v[Math.min(i, v.length - 1)] : v; }
    function distance(a, b) { if (!(a instanceof Array) || !(b instanceof Array)) return Math.abs(b - a); var sum = 0; for (var i = 0; i < Math.min(a.length, b.length); i++) sum += Math.pow(b[i] - a[i], 2); return Math.sqrt(sum); }
    function average(s, incoming, dim) {
        var n = incoming ? s.previous : s.next;
        if (!n || Math.abs(s.time - n.time) < 0.0000001) return null;
        var delta = s.spatial ? distance(s.value, n.value) : incoming ? component(s.value, dim) - component(n.value, dim) : component(n.value, dim) - component(s.value, dim);
        var value = delta / Math.abs(s.time - n.time);
        return isFinite(value) ? value : null;
    }
    function mappedEase(src, dst, incoming) {
        var original = incoming ? src.inEase : src.outEase, target = incoming ? dst.inEase : dst.outEase, out = [];
        for (var i = 0; i < target.length; i++) {
            var e = original[Math.min(i, original.length - 1)], s = average(src, incoming, i), d = average(dst, incoming, i), speed = e.speed;
            if (s !== null && d !== null && Math.abs(s) > 0.0000001) speed *= d / s;
            if (dst.spatial) speed = Math.abs(speed);
            out.push(new KeyframeEase(speed, Math.max(0.1, Math.min(100, e.influence))));
        }
        return out;
    }
    function pasteKeys(c, a) {
        if (!clipboard.length) H.fail('Copy keyframes before pasting.');
        var ps = H.keyProps(c), targets = [], i, j;
        H.unlocked(c.selectedLayers);
        for (i = 0; i < ps.length; i++) for (j = 0; j < ps[i].p.selectedKeys.length; j++) targets.push({ p: ps[i].p, key: ps[i].p.selectedKeys[j] });
        if (!targets.length || targets.length % clipboard.length) H.fail('Select the same number of keys as the clipboard, or a multiple of that number.');
        for (i = 0; i < targets.length; i++) {
            var t = targets[i], src = clipboard[i % clipboard.length], p = t.p, k = t.key;
            if (a.mode === 'values') {
                if (p.propertyValueType !== src.type) H.fail('Paste Values needs matching property types.');
                t.oldValue = p.keyValue(k);
            } else {
                if (!p.isInterpolationTypeValid(src.inType) || !p.isInterpolationTypeValid(src.outType) || !src.inEase) H.fail('These properties do not support the copied easing.');
                var dst = H.snapshot(p, k); dst.spatial = p.isSpatial;
                dst.previous = k > 1 ? { value: p.keyValue(k - 1), time: p.keyTime(k - 1) } : null;
                dst.next = k < p.numKeys ? { value: p.keyValue(k + 1), time: p.keyTime(k + 1) } : null;
                t.old = dst; t.ins = mappedEase(src, dst, true); t.outs = mappedEase(src, dst, false);
            }
        }
        var done = [];
        try {
            for (i = 0; i < targets.length; i++) {
                t = targets[i]; src = clipboard[i % clipboard.length]; done.push(t);
                if (a.mode === 'values') t.p.setValueAtKey(t.key, src.value);
                else {
                    t.p.setTemporalAutoBezierAtKey(t.key, false); t.p.setTemporalContinuousAtKey(t.key, false);
                    t.p.setInterpolationTypeAtKey(t.key, src.inType, src.outType);
                    t.p.setTemporalEaseAtKey(t.key, t.ins, t.outs);
                    t.p.setTemporalContinuousAtKey(t.key, !!src.cont); t.p.setTemporalAutoBezierAtKey(t.key, !!src.auto);
                }
            }
        } catch (e) {
            for (i = 0; i < done.length; i++) { t = done[i]; if (a.mode === 'values') t.p.setValueAtKey(t.key, t.oldValue); else { t.p.setInterpolationTypeAtKey(t.key, t.old.inType, t.old.outType); t.p.setTemporalEaseAtKey(t.key, t.old.inEase, t.old.outEase); t.p.setTemporalContinuousAtKey(t.key, t.old.cont); t.p.setTemporalAutoBezierAtKey(t.key, t.old.auto); } }
            throw e;
        }
        return result('Pasted ' + (a.mode === 'values' ? 'values' : 'easing') + ' to ' + targets.length + ' keys.', { clipboardCount: clipboard.length });
    }
    function autobox(c, a) {
        var type = a.mode;
        if (type !== 'Null' && type !== 'FX' && type !== 'Matte' && type !== 'Fill') H.fail('Unknown Autobox type.');
        var l = c.layers.addShape();
        try {
            l.name = type; l.adjustmentLayer = type === 'Null' || type === 'FX';
            var group = l.property('ADBE Root Vectors Group').addProperty('ADBE Vector Group'); group.name = 'Box';
            var contents = group.property('ADBE Vectors Group');
            var size = contents.addProperty('ADBE Vector Shape - Rect').property('ADBE Vector Rect Size');
            if (type === 'Null') size.setValue([300, 300]); else size.expression = '[thisComp.width, thisComp.height]';
            var fill = contents.addProperty('ADBE Vector Graphic - Fill'); fill.property('ADBE Vector Fill Color').setValue(type === 'Fill' ? [0,0,0] : type === 'Matte' ? [0,1,0] : [1,1,1]);
            var position = l.property('ADBE Transform Group').property('ADBE Position');
            if (type === 'Null') position.setValue([c.width/2,c.height/2]); else position.expression = '[thisComp.width/2, thisComp.height/2]';
            var selected = c.selectedLayers; for (var i = 0; i < selected.length; i++) selected[i].selected = false; l.selected = true;
        } catch (e) { l.remove(); throw e; }
        return 'Created ' + type + (type === 'Null' ? ' without parenting.' : '.');
    }
    function expressionProps(c) {
        var out = [], ls = c.selectedLayers;
        function add(p) { if (!p.canSetExpression) return; for (var j = 0; j < out.length; j++) if (out[j] === p) return; out.push(p); }
        for (var i = 0; i < ls.length; i++) { var ps = ls[i].selectedProperties; for (var j = 0; j < ps.length; j++) H.walk(ps[j], add); }
        if (!out.length) H.fail('Select properties in the Timeline first.');
        return out;
    }
    function readExpression(c) {
        var ps = expressionProps(c), text = '', name = '';
        for (var i = 0; i < ps.length; i++) if (ps[i].expression) {
            if (text && text !== ps[i].expression) H.fail('Select one expression, or properties with the same expression.');
            text = ps[i].expression; name = ps[i].name;
        }
        if (!text) H.fail('The selected properties have no expression to save.');
        return result('Expression ready to save.', { code: text, name: name });
    }
    function applyExpression(c, a) {
        var ps = expressionProps(c), code = String(a.code || ''), originals = [], i;
        if (!code || code.length > 100000) H.fail('Choose a saved expression first.');
        H.unlocked(c.selectedLayers);
        for (i = 0; i < ps.length; i++) { if (ps[i].expression && ps[i].expression !== code && !a.replace) H.fail('A selected property already has an expression. Enable Replace existing to overwrite it.'); originals.push({ code: ps[i].expression, enabled: ps[i].expressionEnabled }); }
        try {
            for (i = 0; i < ps.length; i++) { ps[i].expression = code; ps[i].expressionEnabled = true; ps[i].valueAtTime(c.time, false); if (ps[i].expressionError) H.fail(ps[i].name + ': ' + ps[i].expressionError); }
        } catch (e) { for (i = 0; i < ps.length; i++) { ps[i].expression = originals[i].code; if (originals[i].code) ps[i].expressionEnabled = originals[i].enabled; } throw e; }
        return 'Applied expression to ' + ps.length + ' properties.';
    }
    return { clipboardCount: function () { return clipboard.length; }, actions: { copyEase: copyKeys, pasteEase: pasteKeys, autobox: autobox, readExpression: readExpression, applyExpression: applyExpression } };
}());
