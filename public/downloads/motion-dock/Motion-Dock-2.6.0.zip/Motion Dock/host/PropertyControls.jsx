/* Build typed Expression Controls on one empty shape-layer controller. */
var MotionDockPropertyControls=(function(){
 var H=MotionDock.helpers,TAG='[MotionDock:MasterControls:v1]';
 function literal(s){return '"'+String(s).replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r/g,'\\r').replace(/\n/g,'\\n')+'"';}
 function kind(p,layer){var t=p.propertyValueType;if(layer&&!layer.threeDLayer&&p.matchName==='ADBE Position')return 'ADBE Point Control';if(t===PropertyValueType.COLOR)return 'ADBE Color Control';if(t===PropertyValueType.TwoD||t===PropertyValueType.TwoD_SPATIAL)return 'ADBE Point Control';if(t===PropertyValueType.ThreeD||t===PropertyValueType.ThreeD_SPATIAL)return 'ADBE Point3D Control';if(t===PropertyValueType.OneD)return /Rotate|Rotation|Angle|Skew/.test(p.matchName)||p.unitsText==='degrees'||p.unitsText==='°'?'ADBE Angle Control':'ADBE Slider Control';return null;}
 function unique(base,exists){var name=base,n=2;while(exists(name))name=base+' '+n++;return name;}
 function pathName(p){var parts=[p.name],parent=p.parentProperty;while(parent&&parent.propertyDepth>0){if(parent.matchName!=='ADBE Effect Parade'&&parent.matchName!=='ADBE Transform Group')parts.unshift(parent.name);parent=parent.parentProperty;}return parts.join(' · ');}
 // AE can report isSpatial=true for COLOR, although spatial tangent calls fail.
 function spatial(p){return p.propertyValueType===PropertyValueType.TwoD_SPATIAL||p.propertyValueType===PropertyValueType.ThreeD_SPATIAL;}
 function keySnapshot(p,k){var key={time:p.keyTime(k),value:p.keyValue(k),inType:p.keyInInterpolationType(k),outType:p.keyOutInterpolationType(k)};
  if(p.isInterpolationTypeValid(KeyframeInterpolationType.BEZIER)&&key.inType!==KeyframeInterpolationType.HOLD&&key.outType!==KeyframeInterpolationType.HOLD){key.inEase=p.keyInTemporalEase(k);key.outEase=p.keyOutTemporalEase(k);try{key.auto=p.keyTemporalAutoBezier(k);key.cont=p.keyTemporalContinuous(k);}catch(_){key.auto=false;key.cont=false;}}
  if(spatial(p)){key.inTangent=p.keyInSpatialTangent(k);key.outTangent=p.keyOutSpatialTangent(k);key.sAuto=p.keySpatialAutoBezier(k);key.sCont=p.keySpatialContinuous(k);key.roving=p.keyRoving(k);}
  try{key.label=p.keyLabel(k);}catch(_){}return key;
 }
 function snapshot(p,c){var s={p:p,value:p.valueAtTime(c.time,true),keys:[],expression:p.expression,enabled:p.expressionEnabled};for(var k=1;k<=p.numKeys;k++){var key=keySnapshot(p,k);key.selected=false;var selected=p.selectedKeys;for(var n=0;n<selected.length;n++)if(selected[n]===k)key.selected=true;s.keys.push(key);}return s;}
 function fit(p,v){var target=p.value;return v instanceof Array&&target instanceof Array&&v.length!==target.length?v.slice(0,target.length):v;}
 function write(p,s){var i,k;if(!s.keys.length){p.setValue(fit(p,s.value));return;}for(i=0;i<s.keys.length;i++)p.setValueAtTime(s.keys[i].time,fit(p,s.keys[i].value));for(i=0;i<s.keys.length;i++){var key=s.keys[i];k=i+1;p.setInterpolationTypeAtKey(k,key.inType,key.outType);if(key.inEase&&key.inType!==KeyframeInterpolationType.HOLD&&key.outType!==KeyframeInterpolationType.HOLD){var ins=[],outs=[],count=p.keyInTemporalEase(k).length;for(var j=0;j<count;j++){ins.push(key.inEase[Math.min(j,key.inEase.length-1)]);outs.push(key.outEase[Math.min(j,key.outEase.length-1)]);}p.setTemporalEaseAtKey(k,ins,outs);try{p.setTemporalContinuousAtKey(k,key.cont);p.setTemporalAutoBezierAtKey(k,key.auto);}catch(_){}}if(spatial(p)&&key.inTangent){p.setSpatialTangentsAtKey(k,fit(p,key.inTangent),fit(p,key.outTangent));p.setSpatialContinuousAtKey(k,key.sCont);p.setSpatialAutoBezierAtKey(k,key.sAuto);}if(key.label!==undefined)try{p.setLabelAtKey(k,key.label);}catch(_){}try{p.setSelectedAtKey(k,!!key.selected);}catch(_){}}
  if(spatial(p))for(i=1;i<s.keys.length-1;i++)p.setRovingAtKey(i+1,!!s.keys[i].roving);
 }
 function collect(c){var layers=c.selectedLayers,out=[];H.unlocked(layers);for(var i=0;i<layers.length;i++){var ps=layers[i].selectedProperties;for(var j=0;j<ps.length;j++){var p=ps[j];if(p.propertyType!==PropertyType.PROPERTY)continue;var duplicate=false;for(var n=0;n<out.length;n++)if(out[n].p===p)duplicate=true;if(duplicate)continue;if(!p.canSetExpression||!kind(p,layers[i]))H.fail('Select numeric, angle, point or colour properties. '+p.name+' cannot be linked to an Expression Control.');if(p.isSeparationLeader&&p.dimensionsSeparated)H.fail('Select individual X/Y/Z Position properties when dimensions are separated.');if(p.expression)H.fail(layers[i].name+' · '+p.name+' already has an expression. Existing expressions were kept; no controls were created.');out.push({p:p,layer:layers[i],kind:kind(p,layers[i]),label:pathName(p),original:snapshot(p,c)});}}
  if(!out.length)H.fail('Select individual properties in the Timeline, then click Create Control.');out.sort(function(a,b){if(a.layer.index!==b.layer.index)return a.layer.index-b.layer.index;return a.p.propertyIndex-b.p.propertyIndex;});return out;
 }
 function master(c){var tagged=[],named=[];for(var i=1;i<=c.numLayers;i++){var l=c.layer(i),vectors=l.property('ADBE Root Vectors Group');if(!vectors||vectors.numProperties)continue;if(l.comment.indexOf(TAG)>=0)tagged.push(l);else if(l.name==='Master Controls')named.push(l);}var candidates=tagged.length?tagged:named;if(candidates.length>1)H.fail('More than one Master Controls layer was found. Give the spare controller a different name before linking.');return candidates.length?candidates[0]:null;}
 function create(c,a){var plans=collect(c),shared=a.mode==='shared',m=master(c),madeMaster=false,added=[],changed=[],oldComment=m?m.comment:'',i,j;
  if(m&&m.locked)H.fail('Unlock the Master Controls layer first.');
  for(i=0;i<plans.length;i++){if(plans[i].layer===m)H.fail('Select source properties outside Master Controls to avoid linking a controller to itself.');if(shared&&plans[i].kind!==plans[0].kind)H.fail('A shared control needs compatible properties of the same type. Use One per property for mixed selections.');}
  try{
   if(!m){m=c.layers.addShape();madeMaster=true;m.name=unique('Master Controls',function(name){for(var n=1;n<=c.numLayers;n++)if(c.layer(n)!==m&&c.layer(n).name===name)return true;return false;});m.label=9;m.inPoint=0;m.outPoint=c.duration;}
   // Name-based expressions must resolve to exactly one controller layer.
   var matching=0;for(i=1;i<=c.numLayers;i++)if(c.layer(i).name===m.name)matching++;if(matching!==1)H.fail('The controller name is duplicated. Rename the other layer before linking.');
   var count=shared?1:plans.length;
   for(i=0;i<count;i++){
    var plan=plans[i],base=shared?'Shared · '+plan.label:plan.layer.name+' · '+plan.label;
    var name=unique(base,function(name){var fx=m.property('ADBE Effect Parade');for(var n=1;n<=fx.numProperties;n++)if(fx.property(n).name===name)return true;return false;});
    var fx=m.property('ADBE Effect Parade'),effect=fx.addProperty(plan.kind),index=effect.propertyIndex;effect.name=name;added.push({index:index,name:name});var p=effect.property(1);
    if(plan.original.keys.length&&spatial(plan.p)!==spatial(p))H.fail('The selected animated point uses a different interpolation type from this control. No links were changed.');
    write(p,plan.original);
   }
   for(i=0;i<plans.length;i++){
    var target=plans[i],control=added[shared?0:i];changed.push(target);
    target.p.expression='// Motion Dock control link\nthisComp.layer('+literal(m.name)+').effect('+literal(control.name)+')(1);';target.p.expressionEnabled=true;target.p.valueAtTime(c.time,false);if(target.p.expressionError)H.fail(target.label+': '+target.p.expressionError);
   }
   // Animation now lives on the controller, rather than under an overriding expression.
   for(i=0;i<plans.length;i++){var p=plans[i].p;for(j=p.numKeys;j>=1;j--)p.removeKey(j);p.valueAtTime(c.time,false);if(p.expressionError)H.fail(plans[i].label+': '+p.expressionError);}
   if(m.comment.indexOf(TAG)<0)m.comment=(m.comment?m.comment+'\n':'')+TAG;
   var selected=c.selectedLayers;for(i=0;i<selected.length;i++)selected[i].selected=false;m.selected=true;
   for(i=0;i<added.length;i++)m.property('ADBE Effect Parade').property(added[i].index).selected=true;
   return 'Linked '+plans.length+' properties to '+added.length+(shared?' shared control':' separate control'+(added.length===1?'':'s'))+' on '+m.name+'. Values and supported keyframe animation preserved.';
  }catch(e){
   for(i=changed.length-1;i>=0;i--){var state=changed[i].original,p=state.p;try{p.expression='';for(j=p.numKeys;j>=1;j--)p.removeKey(j);write(p,state);p.expression=state.expression;if(state.expression)p.expressionEnabled=state.enabled;}catch(_){}}
   if(madeMaster&&m)try{m.remove();}catch(_){}else if(m){for(i=added.length-1;i>=0;i--)try{m.property('ADBE Effect Parade').property(added[i].index).remove();}catch(_){}try{m.comment=oldComment;}catch(_){}}
   throw e;
  }
 }
 return {actions:{createControl:create}};
}());
