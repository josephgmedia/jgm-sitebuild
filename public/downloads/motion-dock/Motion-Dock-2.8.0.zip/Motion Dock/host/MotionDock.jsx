/* Motion Dock 2.8.0 — ExtendScript host. */
var MotionDock = (function () {
    function fail(s) { throw new Error(s); }
    function encode(o) {
        function quote(s) { return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"'; }
        function pack(v) {
            if (v === null || v === undefined) return 'null';
            if (typeof v === 'string') return quote(v);
            if (typeof v === 'number') return isFinite(v) ? String(v) : 'null';
            if (typeof v === 'boolean') return v ? 'true' : 'false';
            var a = [], k;
            if (v instanceof Array) { for (k = 0; k < v.length; k++) a.push(pack(v[k])); return '[' + a.join(',') + ']'; }
            for (k in v) if (v.hasOwnProperty(k)) a.push(quote(k) + ':' + pack(v[k]));
            return '{' + a.join(',') + '}';
        }
        return pack(o);
    }
    function comp() { var c = app.project.activeItem; if (!(c instanceof CompItem)) fail('Open a composition first.'); return c; }
    function layers(c) { var a = c.selectedLayers; if (!a.length) fail('Select one or more layers.'); return a; }
    function unlocked(a) { for (var i = 0; i < a.length; i++) if (a[i].locked) fail('Unlock selected layers first.'); }
    function walk(p, fn) {
        if (p.propertyType === PropertyType.PROPERTY) fn(p);
        else for (var i = 1; i <= p.numProperties; i++) walk(p.property(i), fn);
    }
    function keyProps(c) {
        var out = [], ls = c.selectedLayers;
        for (var i = 0; i < ls.length; i++) walk(ls[i], function (p) { if (p.numKeys && p.selectedKeys.length) out.push({ p: p, layer: ls[i] }); });
        return out;
    }
    function selectedProps(c) {
        var out = [], ls = c.selectedLayers;
        function add(p) { for (var j = 0; j < out.length; j++) if (out[j] === p) return; out.push(p); }
        for (var i = 0; i < ls.length; i++) {
            var ps = ls[i].selectedProperties;
            for (var k = 0; k < ps.length; k++) walk(ps[k], function (p) { if (p.canSetExpression && p.numKeys >= 2) add(p); });
        }
        return out;
    }
    function snapshot(p, k) {
        var s = { time: p.keyTime(k), value: p.keyValue(k), inType: p.keyInInterpolationType(k), outType: p.keyOutInterpolationType(k) };
        if (p.isInterpolationTypeValid(KeyframeInterpolationType.BEZIER)) {
            s.inEase = p.keyInTemporalEase(k); s.outEase = p.keyOutTemporalEase(k);
            s.auto = p.keyTemporalAutoBezier(k); s.cont = p.keyTemporalContinuous(k);
        }
        if (p.isSpatial) {
            s.inTangent = p.keyInSpatialTangent(k); s.outTangent = p.keyOutSpatialTangent(k);
            s.sAuto = p.keySpatialAutoBezier(k); s.sCont = p.keySpatialContinuous(k); s.roving = p.keyRoving(k);
        }
        try { s.label = p.keyLabel(k); } catch (_) {}
        return s;
    }
    function negEase(a) { var b = []; for (var i = 0; i < a.length; i++) b.push(new KeyframeEase(-a[i].speed, a[i].influence)); return b; }
    function writeKey(p, s, time, reverse, selected) {
        p.setValueAtTime(time, s.value);
        var k = p.nearestKeyIndex(time);
        p.setInterpolationTypeAtKey(k, reverse ? s.outType : s.inType, reverse ? s.inType : s.outType);
        if (s.inEase) {
            // Spatial speed is a magnitude. Scalar/vector temporal derivatives change sign under reversal.
            p.setTemporalEaseAtKey(k, reverse ? (p.isSpatial ? s.outEase : negEase(s.outEase)) : s.inEase, reverse ? (p.isSpatial ? s.inEase : negEase(s.inEase)) : s.outEase);
            p.setTemporalContinuousAtKey(k, s.cont); p.setTemporalAutoBezierAtKey(k, s.auto);
        }
        if (p.isSpatial) {
            p.setSpatialTangentsAtKey(k, reverse ? s.outTangent : s.inTangent, reverse ? s.inTangent : s.outTangent);
            p.setSpatialContinuousAtKey(k, s.sCont); p.setSpatialAutoBezierAtKey(k, s.sAuto);
            // Preserve exact target times; roving would move the new keys.
            p.setRovingAtKey(k, false);
        }
        if (s.label !== undefined) try { p.setLabelAtKey(k, s.label); } catch (_) {}
        p.setSelectedAtKey(k, !!selected);
    }
    function collision(p, time, excluded) {
        if (!p.numKeys) return false;
        var k = p.nearestKeyIndex(time);
        if (Math.abs(p.keyTime(k) - time) > .000001) return false;
        for (var i = 0; excluded && i < excluded.length; i++) if (excluded[i] === k) return false;
        return true;
    }
    function ease(c, a) {
        var ps = keyProps(c), n = 0;
        if (!ps.length) fail('Select keyframes to adjust easing.');
        unlocked(c.selectedLayers);
        var v = Math.max(.1, Math.min(100, Number(a.value)));
        if (!isFinite(v)) fail('Enter an influence from 0.1 to 100.');
        for (var i = 0; i < ps.length; i++) {
            var p = ps[i].p, ks = p.selectedKeys;
            if (!p.isInterpolationTypeValid(KeyframeInterpolationType.BEZIER)) continue;
            for (var j = 0; j < ks.length; j++) {
                var k = ks[j], ins = p.keyInTemporalEase(k), outs = p.keyOutTemporalEase(k), x;
                p.setTemporalAutoBezierAtKey(k, false); p.setTemporalContinuousAtKey(k, false);
                var it = p.keyInInterpolationType(k), ot = p.keyOutInterpolationType(k);
                if (a.side !== 'out') { it = KeyframeInterpolationType.BEZIER; for (x = 0; x < ins.length; x++) ins[x] = new KeyframeEase(0, v); }
                if (a.side !== 'in') { ot = KeyframeInterpolationType.BEZIER; for (x = 0; x < outs.length; x++) outs[x] = new KeyframeEase(0, v); }
                p.setInterpolationTypeAtKey(k, it, ot); p.setTemporalEaseAtKey(k, ins, outs); n++;
            }
        }
        if (!n) fail('These properties do not support Bezier easing.');
        return 'Easing applied to ' + n + ' keyframes.';
    }
    function preset(c, a) {
        if (a.mode === 'bezier') return ease(c, { side: 'both', value: 33.333 });
        var ps = keyProps(c), n = 0, t = a.mode === 'hold' ? KeyframeInterpolationType.HOLD : KeyframeInterpolationType.LINEAR;
        unlocked(c.selectedLayers);
        for (var i = 0; i < ps.length; i++) { var p = ps[i].p, ks = p.selectedKeys; if (!p.isInterpolationTypeValid(t)) continue;
            for (var j = 0; j < ks.length; j++) { p.setInterpolationTypeAtKey(ks[j], t, t); n++; }
        }
        if (!n) fail('Select compatible keyframes first.'); return 'Interpolation applied to ' + n + ' keyframes.';
    }
    function clone(c, a) {
        var ps = keyProps(c), start = Infinity, end = -Infinity, plans = [], n = 0;
        if (!ps.length) fail('Select keyframes to clone.'); unlocked(c.selectedLayers);
        for (var i = 0; i < ps.length; i++) { var ks = ps[i].p.selectedKeys, snaps = [];
            for (var j = 0; j < ks.length; j++) { var s = snapshot(ps[i].p, ks[j]); start = Math.min(start, s.time); end = Math.max(end, s.time); snaps.push(s); }
            plans.push({ p: ps[i].p, keys: snaps });
        }
        for (i = 0; i < plans.length; i++) for (j = 0; j < plans[i].keys.length; j++) {
            s = plans[i].keys[j]; s.target = c.time + (a.shift ? end - s.time : s.time - start);
            // Like pasting keys in AE, an existing destination key is replaced.
        }
        if (a.alt) for (i = 0; i < plans.length; i++) { ks = plans[i].p.selectedKeys; for (j = 0; j < ks.length; j++) plans[i].p.setSelectedAtKey(ks[j], false); }
        for (i = 0; i < plans.length; i++) for (j = 0; j < plans[i].keys.length; j++) { s = plans[i].keys[j]; writeKey(plans[i].p, s, s.target, a.shift, a.alt); n++; }
        return (a.shift ? 'Reverse cloned ' : 'Cloned ') + n + ' keyframes from the playhead.';
    }
    function sequence(c, a) {
        var all = layers(c), ps = a.target === 'keyframes' ? keyProps(c) : [], ls = [], plans = [], i, j;
        if (a.target !== 'layers' && a.target !== 'keyframes') fail('Choose Layers or Keyframes in the Sequence dropdown.');
        if (a.target === 'keyframes' && !ps.length) fail('Select keyframes to sequence, or choose Layers in the dropdown.');
        unlocked(all);
        var amount = Number(a.amount), step = Number(a.step);
        if (!isFinite(amount) || amount < 0 || amount % 1 || !isFinite(step) || step < 1 || step % 1) fail('Use whole frames ≥ 0 and a Step ≥ 1.');
        if (ps.length) {
            for (i = 0; i < ps.length; i++) { var found = false; for (j = 0; j < ls.length; j++) if (ls[j] === ps[i].layer) found = true; if (!found) ls.push(ps[i].layer); }
        } else for (i = 0; i < all.length; i++) ls.push(all[i]);
        ls.sort(function (x, y) { return a.mode === 'up' ? y.index - x.index : x.index - y.index; });
        for (i = 0; i < ls.length; i++) {
            var offset = Math.floor(i / step) * amount * c.frameDuration;
            if (!offset) continue;
            if (!ps.length) { plans.push({ layer: ls[i], target: ls[i].startTime + offset }); continue; }
            for (j = 0; j < ps.length; j++) if (ps[j].layer === ls[i]) {
                var p = ps[j].p, ks = p.selectedKeys, snaps = [];
                for (var k = 0; k < ks.length; k++) { var s = snapshot(p, ks[k]); s.target = s.time + offset; if (collision(p, s.target, ks)) fail('Sequencing would overwrite an unselected keyframe. Reduce Amount or change the selection.'); snaps.push(s); }
                plans.push({ p: p, indices: ks, keys: snaps });
            }
        }
        for (i = 0; i < plans.length; i++) {
            var plan = plans[i];
            if (plan.layer) plan.layer.startTime = plan.target;
            else { for (j = plan.indices.length - 1; j >= 0; j--) plan.p.removeKey(plan.indices[j]); for (j = 0; j < plan.keys.length; j++) writeKey(plan.p, plan.keys[j], plan.keys[j].target, false, true); }
        }
        return 'Sequenced ' + ls.length + ' layers' + (ps.length ? ' of selected keys.' : '.');
    }
    function loop(c, a) {
        var ps = selectedProps(c), type = a.ctrl ? 'continue' : a.shift ? 'offset' : a.alt ? 'pingpong' : 'cycle';
        if (!ps.length) fail('Select animated properties with at least two keys.'); unlocked(c.selectedLayers);
        for (var i = 0; i < ps.length; i++) {
            if (ps[i].expression) fail('A selected property already has an expression. Remove it before adding a loop.');
            if (ps[i].propertyValueType === PropertyValueType.SHAPE || ps[i].propertyValueType === PropertyValueType.TEXT_DOCUMENT || ps[i].propertyValueType === PropertyValueType.CUSTOM_VALUE) fail('Loop expressions are supported on numeric properties.');
        }
        for (i = 0; i < ps.length; i++) {
            ps[i].expression = 'loopOut("' + type + '")';
            if (ps[i].expressionError) fail('After Effects rejected a loop expression: ' + ps[i].expressionError);
        }
        return 'Added ' + type + ' loop to ' + ps.length + ' properties.';
    }
    function static2D(l, purpose) {
        if (l.threeDLayer) fail(purpose + ' currently supports 2D layers.');
        var t = l.property('ADBE Transform Group'), names = ['ADBE Anchor Point', 'ADBE Position', 'ADBE Scale', 'ADBE Rotate Z'];
        for (var i = 0; i < names.length; i++) { var p = t.property(names[i]); if (!p) fail('Select visual layers with transforms.'); if (p.numKeys || p.expressionEnabled || (p.isSeparationLeader && p.dimensionsSeparated)) fail(purpose + ' requires static, unseparated transforms.'); }
        if (l.autoOrient !== AutoOrientType.NO_AUTO_ORIENT) fail('Disable auto-orientation before ' + purpose.toLowerCase() + '.');
    }
    function anchor(c, a) {
        var ls = layers(c), edits = [], originals = [], i, j;
        unlocked(ls);
        function remember(p) {
            var state = {p:p, expression:p.expression, enabled:p.expressionEnabled, keys:[], value:null};
            for (var k=1;k<=p.numKeys;k++) state.keys.push(snapshot(p,k));
            if (!p.numKeys) state.value=p.value;
            originals.push(state); return state;
        }
        function offset(p, delta) {
            var state=remember(p), k;
            if (p.expressionEnabled) {
                edits.push({p:p,expression:'var __mdBase = eval('+encode(p.expression)+'); __mdBase + '+encode(delta)+';'});
            } else {
                var data=[]; for(k=0;k<state.keys.length;k++) data.push({value:state.keys[k].value});
                if (!data.length) edits.push({p:p,value:add(state.value,delta)});
                else { for(k=0;k<data.length;k++) data[k].value=add(data[k].value,delta); edits.push({p:p,keys:data}); }
            }
        }
        function add(v,d) { if (!(v instanceof Array)) return v+d; var out=v.slice(0);for(var k=0;k<d.length;k++)out[k]+=d[k];return out; }
        for (i=0;i<ls.length;i++) {
            var l=ls[i];
            if(l.threeDLayer) fail('Anchor reposition currently supports 2D layers.');
            if(l.autoOrient!==AutoOrientType.NO_AUTO_ORIENT) fail('Disable auto-orientation before repositioning the anchor.');
            var r=l.sourceRectAtTime(c.time,true),t=l.property('ADBE Transform Group'),ap=t.property('ADBE Anchor Point'),pos=t.property('ADBE Position'),sc=t.property('ADBE Scale'),rot=t.property('ADBE Rotate Z');
            var old=ap.valueAtTime(c.time,false),target=[r.left+r.width*a.x,r.top+r.height*a.y],d=[target[0]-old[0],target[1]-old[1]];
            offset(ap,d);
            var dynamic=sc.numKeys||sc.expressionEnabled||rot.numKeys||rot.expressionEnabled;
            var scale=sc.valueAtTime(c.time,false),angle=rot.valueAtTime(c.time,false)*Math.PI/180,dx=d[0]*scale[0]/100,dy=d[1]*scale[1]/100;
            var compensation=[dx*Math.cos(angle)-dy*Math.sin(angle),dx*Math.sin(angle)+dy*Math.cos(angle)];
            var separated=pos.isSeparationLeader&&pos.dimensionsSeparated,dimensions=separated?2:1;
            for(j=0;j<dimensions;j++) {
                var p=separated?pos.getSeparationFollower(j):pos;
                if(!dynamic) { offset(p,separated?compensation[j]:compensation); continue; }
                remember(p);
                var base=p.expressionEnabled?'eval('+encode(p.expression)+')':'value';
                var expression='var __mdBase = '+base+'; var __mdD = '+encode(d)+'; var __mdS = transform.scale/100; var __mdR = degreesToRadians(transform.rotation); var __mdX = __mdD[0]*__mdS[0]; var __mdY = __mdD[1]*__mdS[1]; var __mdOffset = [__mdX*Math.cos(__mdR)-__mdY*Math.sin(__mdR),__mdX*Math.sin(__mdR)+__mdY*Math.cos(__mdR)]; __mdBase + __mdOffset'+(separated?'['+j+']':'')+';';
                edits.push({p:p,expression:expression});
            }
        }
        try {
            for(i=0;i<edits.length;i++) {
                var edit=edits[i],p=edit.p;
                if(edit.expression!==undefined) { p.expression=edit.expression; if(p.expressionError)fail('Anchor compensation: '+p.expressionError); }
                else if(edit.keys) { for(j=0;j<edit.keys.length;j++)p.setValueAtKey(j+1,edit.keys[j].value); }
                else p.setValue(edit.value);
            }
        } catch(e) {
            // Restore all properties if expression validation fails.
            for(i=0;i<originals.length;i++) {
                var state=originals[i],p=state.p; p.expression='';
                for(j=0;j<state.keys.length;j++)p.setValueAtKey(j+1,state.keys[j].value);
                if(!state.keys.length)p.setValue(state.value);
                p.expression=state.expression;p.expressionEnabled=state.enabled;
            }
            throw e;
        }
        return 'Repositioned '+ls.length+' anchors; animation preserved.';
    }
    function groupNull(c) {
        var ls = layers(c); unlocked(ls);
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, roots = [], i, j;
        for (i = 0; i < ls.length; i++) {
            var l = ls[i], ancestor = l.parent, hasSelectedAncestor = false;
            if (l.threeDLayer || !l.sourceRectAtTime) fail('Group null currently supports visual 2D layers.');
            while (ancestor) { if (ancestor.threeDLayer) fail('Group null requires a 2D parent chain.'); for (j = 0; j < ls.length; j++) if (ancestor === ls[j]) hasSelectedAncestor = true; ancestor = ancestor.parent; }
            if (!hasSelectedAncestor) roots.push(l);
            var r = l.sourceRectAtTime(c.time, true), points = [[r.left,r.top],[r.left+r.width,r.top],[r.left,r.top+r.height],[r.left+r.width,r.top+r.height]];
            for (j = 0; j < points.length; j++) { var p = l.sourcePointToComp(points[j]); minX = Math.min(minX,p[0]); minY = Math.min(minY,p[1]); maxX = Math.max(maxX,p[0]); maxY = Math.max(maxY,p[1]); }
        }
        if (!isFinite(minX)) fail('Could not measure the selected bounds.');
        // Multiple roots with different parents cannot share a new parent without losing inherited animation.
        var commonParent = roots[0].parent;
        for (i = 1; i < roots.length; i++) if (roots[i].parent !== commonParent) fail('Select root layers with the same parent to preserve their inherited animation.');
        var n = c.layers.addShape(); n.name = 'Null'; n.adjustmentLayer = true; n.label = 9;
        try {
            var contents = n.property('ADBE Root Vectors Group'), g = contents.addProperty('ADBE Vector Group'); g.name = 'Box';
            var v = g.property('ADBE Vectors Group'); v.addProperty('ADBE Vector Shape - Rect').property('ADBE Vector Rect Size').setValue([300,300]);
            v.addProperty('ADBE Vector Graphic - Fill').property('ADBE Vector Fill Color').setValue([1,1,1]);
            n.property('ADBE Transform Group').property('ADBE Position').setValue([(minX+maxX)/2,(minY+maxY)/2]);
            if (commonParent) n.parent = commonParent;
            var top = ls[0]; for (i = 1; i < ls.length; i++) if (ls[i].index < top.index) top = ls[i]; n.moveBefore(top);
            // Assigning .parent compensates transforms; setParentWithJump would move artwork.
            for (i = 0; i < roots.length; i++) roots[i].parent = n;
            for (i = 0; i < ls.length; i++) ls[i].selected = false; n.selected = true;
        } catch (e) { for (i = 0; i < roots.length; i++) if (roots[i].parent === n) roots[i].parent = commonParent; n.remove(); throw e; }
        return 'Created a 300 × 300 shape null at the selection bounds centre.';
    }
    function crop(c) {
        // ROI is not exposed as a scripting property. Use AE's own menu command.
        c.openInViewer();
        var id = app.findMenuCommandId('Crop Comp to Region of Interest');
        if (!id) fail('Crop command unavailable. This button currently needs the English After Effects interface.');
        app.executeCommand(id);
        return 'Crop command sent. After Effects uses the current region of interest.';
    }
    function run(payload) {
        var begun = false;
        try {
            var request = typeof JSON !== 'undefined' && typeof JSON.parse === 'function' ? JSON.parse(payload) : eval('(' + payload + ')');
            if (request.action === 'hello') return encode({ ok: true, version: '2.8.0', clipboardCount: typeof MotionDockExtras !== 'undefined' ? MotionDockExtras.clipboardCount() : 0, message: 'Connected to After Effects ' + app.version + '. Select layers or keys.' });
            var actions = { ease: ease, easePreset: preset, clone: clone, sequence: sequence, loop: loop, anchor: anchor, 'null': groupNull, crop: crop };
            var action = actions[request.action];
            if (typeof MotionDockExtras !== 'undefined' && MotionDockExtras.actions[request.action]) action = MotionDockExtras.actions[request.action];
            if (!action) fail('Unknown Motion Dock action.');
            var c = (request.action === 'exportInfo' || request.action.indexOf('roi') === 0) ? app.project.activeItem : comp();
            if(request.action !== 'exportStems' && request.action !== 'prerender') { app.beginUndoGroup('Motion Dock · ' + request.action); begun = true; }
            var message = action(c, request.args || {});
            return encode(typeof message === 'string' ? { ok: true, message: message } : message);
        } catch (e) { return encode({ ok: false, message: String(e.message || e) + ' If an edit occurred, use Undo once.' }); }
        finally { if (begun) app.endUndoGroup(); }
    }
    return { run: run, helpers: { fail: fail, layers: layers, unlocked: unlocked, walk: walk, keyProps: keyProps, snapshot: snapshot, writeKey: writeKey } };
}());
if (typeof $ !== 'undefined' && $.fileName) {
    var motionDockExtrasFile = new File(File($.fileName).parent.fsName + '/Tools.jsx');
    if (motionDockExtrasFile.exists) $.evalFile(motionDockExtrasFile);
}
