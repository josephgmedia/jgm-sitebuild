(function(){'use strict';
window.MotionDockUpdater={init:function(api){
  var root=api.root,button=root.querySelector('#check-updates'),dialog=root.querySelector('#update-dialog'),status=root.querySelector('#update-status'),notes=root.querySelector('#update-notes'),install=root.querySelector('#install-update'),again=root.querySelector('#check-updates-again'),core=null,offer=null,checking=false,installed=false,signed=false;
  root.querySelector('#update-current-version').textContent='Installed version '+api.version;
  try{var req=window.cep_node&&window.cep_node.require?window.cep_node.require:typeof window.require==='function'?window.require:null;if(req)core=req(api.extension+'/client/update-core.cjs');}catch(e){status.textContent='The updater could not start. Reinstall Motion Dock from josephgmedia.com/plugins.';}
  if(core&&core.isSigned)signed=core.isSigned(api.extension);
  function message(text){status.textContent=text;}
  async function check(silent){
    if(checking)return;checking=true;again.disabled=true;install.hidden=true;notes.textContent='';
    if(!core){message('Restart After Effects once to enable in-panel updates. Downloads are also available at josephgmedia.com/plugins.');checking=false;again.disabled=false;return;}
    if(!silent)message('Checking for a published release…');
    try{var r=await core.check(api.extension);if(core.newer(r.version,api.version)){offer=r;button.textContent='Update available';button.classList.add('md-update-available');message('Motion Dock '+r.version+' is available.');r.notes.forEach(function(text){var li=document.createElement('li');li.textContent=text;notes.append(li);});install.textContent=(signed?'Download ZXP ':'Install ')+r.version;install.hidden=signed&&!r.installer;if(signed&&!r.installer)message('This release has no signed installer. Visit josephgmedia.com/plugins.');}else{offer=null;button.textContent='Updates';button.classList.remove('md-update-available');message('You’re up to date.');}}
    catch(e){message('Could not check for updates. '+e.message+' Your installed version is unchanged.');}
    finally{checking=false;again.disabled=false;}
  }
  button.onclick=function(){dialog.showModal();if(!installed)check(false);};
  again.onclick=function(){check(false);};
  root.querySelector('#close-update-dialog').onclick=function(){dialog.close();};
  root.querySelector('#reload-after-update').onclick=function(){window.location.reload();};
  dialog.addEventListener('cancel',function(e){if(install.disabled)e.preventDefault();});
  install.onclick=function(){if(!core||!offer)return;api.perform(async function(){install.disabled=true;again.disabled=true;root.querySelector('#close-update-dialog').disabled=true;try{if(signed){var downloaded=await core.downloadInstaller(api.extension,offer,message);core.showInstaller(downloaded.file);install.hidden=true;message('ZXP saved to '+downloaded.file+'. Install it with your ZXP installer, then restart After Effects.');return {message:'Signed update downloaded. Install the ZXP, then restart After Effects.'};}var r=await core.install(api.extension,offer,message);installed=true;install.hidden=true;again.hidden=true;root.querySelector('#reload-after-update').hidden=false;message('Motion Dock '+r.version+' is installed. Click Reload panel to finish.');return {message:'Update installed. Reload Motion Dock to finish.'};}catch(e){message(e.message);throw e;}finally{install.disabled=false;again.disabled=false;root.querySelector('#close-update-dialog').disabled=false;}});};
  if(core)check(true);
}};
})();
