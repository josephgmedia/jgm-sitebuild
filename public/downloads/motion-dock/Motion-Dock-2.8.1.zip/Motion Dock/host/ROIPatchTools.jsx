/* Integrated from user-supplied ROI Patch Manager 1.1.0. Shared record store. */
var MotionDockROI=(function(){
    var VERSION = '1.1.0', records = [], loadError = '', stamp = '';
    var dir = new Folder(Folder.userData.fsName + '/ROI Patch Manager');
    var db = new File(dir.fsName + '/records.json');
    function fail(s) { throw new Error(s); }
    function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
    function quote(s) {
        return '"' + String(s).replace(/[\\"\x00-\x1f]/g, function (c) {
            var n = c.charCodeAt(0).toString(16);
            return c === '"' ? '\\"' : c === '\\' ? '\\\\' : '\\u' + ('0000' + n).slice(-4);
        }) + '"';
    }
    function encode(v) {
        var a = [], k, i;
        if (v === null) return 'null';
        if (typeof v === 'string') return quote(v);
        if (typeof v === 'number') { if (!isFinite(v)) fail('Invalid number'); return String(v); }
        if (typeof v === 'boolean') return String(v);
        if (v instanceof Array) { for (i = 0; i < v.length; i++) a.push(encode(v[i])); return '[' + a.join(',') + ']'; }
        for (k in v) if (own(v, k)) a.push(quote(k) + ':' + encode(v[k]));
        return '{' + a.join(',') + '}';
    }
    // Strict JSON parser: never executes stored content. Bounds nesting and input size.
    function decode(s) {
        var p = 0;
        if (s.length > 8000000) fail('Record file too large');
        function ws() { while (/\s/.test(s.charAt(p)) && p < s.length) p++; }
        function str() {
            var out = '', c, e, h;
            if (s.charAt(p++) !== '"') fail('Expected JSON string');
            while (p < s.length) {
                c = s.charAt(p++);
                if (c === '"') return out;
                if (c === '\\') {
                    e = s.charAt(p++);
                    if (e === 'u') { h = s.substr(p, 4); if (!/^[0-9a-fA-F]{4}$/.test(h)) fail('Bad Unicode'); out += String.fromCharCode(parseInt(h, 16)); p += 4; }
                    else if (e === '"' || e === '\\' || e === '/') out += e;
                    else if (e === 'b') out += '\b'; else if (e === 'f') out += '\f';
                    else if (e === 'n') out += '\n'; else if (e === 'r') out += '\r'; else if (e === 't') out += '\t'; else fail('Bad escape');
                } else { if (c.charCodeAt(0) < 32) fail('Control character'); out += c; }
            }
            fail('Unterminated string');
        }
        function value(depth) {
            var c, out, k, m;
            if (depth > 32) fail('JSON nesting too deep'); ws(); c = s.charAt(p);
            if (c === '"') return str();
            if (c === '{' || c === '[') {
                p++; out = c === '{' ? {} : []; ws();
                if (s.charAt(p) === (c === '{' ? '}' : ']')) { p++; return out; }
                while (true) {
                    ws();
                    if (c === '{') { k = str(); if (k === '__proto__' || k === 'constructor' || k === 'prototype' || own(out, k)) fail('Unsafe/duplicate key'); ws(); if (s.charAt(p++) !== ':') fail('Expected colon'); out[k] = value(depth + 1); }
                    else out.push(value(depth + 1));
                    ws(); k = s.charAt(p++); if (k === (c === '{' ? '}' : ']')) return out;
                    if (k !== ',') fail('Expected comma');
                }
            }
            m = /^(true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/.exec(s.substr(p));
            if (!m) fail('Invalid JSON'); p += m[0].length;
            return m[0] === 'true' ? true : m[0] === 'false' ? false : m[0] === 'null' ? null : Number(m[0]);
        }
        var result = value(0); ws(); if (p !== s.length) fail('Trailing JSON'); return result;
    }
    function read(f) { f.encoding = 'UTF-8'; if (!f.open('r')) fail('Cannot read ' + f.fsName); var s; try { s = f.read(); } finally { f.close(); } return s; }
    function integer(n) { return typeof n === 'number' && isFinite(n) && n >= 0 && Math.floor(n) === n; }
    function valid(r) {
        var keys = ['width','height','left','top','right','bottom'], i;
        if (!r || typeof r.id !== 'string' || typeof r.name !== 'string' || typeof r.path !== 'string') fail('Invalid patch record');
        for (i = 0; i < keys.length; i++) if (!integer(r[keys[i]])) fail('Invalid crop geometry');
        if (r.width < 1 || r.height < 1 || r.width > 300000 || r.height > 300000 || r.left + r.right >= r.width || r.top + r.bottom >= r.height) fail('Crop falls outside master');
        if (typeof r.par !== 'number' || !isFinite(r.par) || r.par <= 0) fail('Invalid pixel aspect ratio');
        if (!/\.exr$/i.test(r.path)) fail('Record must reference EXR output');
        return r;
    }
    function parseDB(s) {
        var o = decode(s), i, ids = {};
        if (!o || o.schema !== 1 || !(o.records instanceof Array) || o.records.length > 10000) fail('Unsupported record database');
        for (i = 0; i < o.records.length; i++) { valid(o.records[i]); if (own(ids, o.records[i].id)) fail('Duplicate record ID'); ids[o.records[i].id] = true; }
        return o.records;
    }
    function load() {
        records = []; loadError = ''; stamp = '';
        try { if (db.exists) { stamp = read(db); records = parseDB(stamp); } }
        catch (e) { loadError = 'Records could not be loaded. Restore records.json from records.json.bak before saving.\n' + e.message; }
    }
    function save(next) {
        if (loadError) fail(loadError);
        if ((db.exists ? read(db) : '') !== stamp) fail('Records changed in another panel. Refresh saved patches and try again.');
        if (!dir.exists && !dir.create()) fail('Cannot create records folder. Enable Allow Scripts to Write Files and Access Network.');
        var s = encode({schema:1, version:VERSION, records:next}), temp = new File(dir.fsName + '/records.pending.json'), bak = new File(db.fsName + '.bak');
        parseDB(s); temp.encoding = 'UTF-8';
        if (!temp.open('w')) fail('Cannot save records. Enable Allow Scripts to Write Files and Access Network.');
        var ok; try { ok = temp.write(s); } finally { temp.close(); }
        if (!ok || read(temp) !== s) fail('Record write verification failed; original preserved.');
        if (db.exists) {
            if (bak.exists && !bak.remove()) fail('Cannot rotate backup; original preserved.');
            if (!db.copy(bak.fsName)) fail('Cannot back up records; original preserved.');
            if (!db.remove()) fail('Cannot replace records; backup preserved.');
        }
        if (!temp.rename('records.json')) { if (bak.exists) bak.copy(db.fsName); fail('Cannot commit records; backup preserved.'); }
        stamp = s; records = next;
    }
    function norm(s) { return String(s).replace(/\\/g, '/'); }
    function base(s) { s = norm(s); return s.substring(s.lastIndexOf('/') + 1); }
    // Only an explicit AE frame token can stand for frame digits. Render versions
    // such as patch1.exr / patch2.exr must remain distinct identities.
    function sequenceMatches(template, concrete) {
        var name=base(template), token=/\[#+\]/.exec(name);
        if(!token)return false;
        function esc(v){return v.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
        var pattern='^'+esc(name.substring(0,token.index))+'[0-9]{'+(token[0].length-2)+',}'+esc(name.substring(token.index+token[0].length))+'$';
        return new RegExp(pattern,'i').test(base(concrete));
    }
    function folder(s) { s = norm(s); return s.substring(0, s.lastIndexOf('/')); }
    function score(a, b) {
        a = norm(a).toLowerCase(); b = norm(b).toLowerCase();
        if (a === b) return 4;
        var sameName=base(a)===base(b), sequence=sequenceMatches(a,b)||sequenceMatches(b,a);
        if (folder(a) === folder(b) && sequence) return 3;
        if (sameName) return 2;
        if (sequence) return 1;
        return 0;
    }
    function best(path) {
        var out = [], high = 0, i, s;
        for (i = 0; i < records.length; i++) { s = score(path, records[i].path); if (s > high) { out = []; high = s; } if (s > 0 && s === high) out.push(i); }
        return out;
    }
    function num(s) { if (typeof s === 'number') return s; if (!/^\s*\d+\s*$/.test(String(s))) fail('Expected an integer crop value, received: ' + s); return Number(s); }
    function setting(o, k) { if (!own(o, k)) fail('AE did not expose "' + k + '". Check Output Module Settings; do not infer offsets from EXR size.'); return o[k]; }
    function enabled(v) { return v === true || v === 1 || String(v).toLowerCase() === 'true'; }
    function inspectOM(om) {
        if (!om.getSettings) fail('Requires AE CC 2014 / 13.0 or later.');
        return om.getSettings(GetSettingsFormat.NUMBER);
    }
    function propStatic(p) {
        if (!p || p.numKeys > 0 || p.expressionEnabled || (p.canSetExpression && p.expression !== '')) fail('Transform has keyframes or an expression. Remove them before aligning.');
    }
    function target() {
        var c = app.project.activeItem;
        if (!(c instanceof CompItem) || c.selectedLayers.length !== 1) fail('Open the destination composition and select exactly one imported EXR layer.');
        var l = c.selectedLayers[0];
        if (!(l instanceof AVLayer) || !(l.source instanceof FootageItem) || !l.source.file || !/\.exr$/i.test(l.source.file.name)) fail('Select an EXR footage layer.');
        return {comp:c, layer:l, path:l.source.file.fsName};
    }
    function geometry(r) { return {w:r.width-r.left-r.right, h:r.height-r.top-r.bottom}; }
    function align(r) {
        valid(r); var t = target(), c = t.comp, l = t.layer, g = geometry(r), tr = l.property('ADBE Transform Group');
        if (!score(t.path, r.path)) fail('Selected record does not match this EXR filename. Capture the correct output filename.');
        if (c.width !== r.width || c.height !== r.height || Math.abs(c.pixelAspect-r.par) > 0.00001) fail('Destination master dimensions / pixel aspect do not match ' + r.width + ' x ' + r.height + ', PAR ' + r.par + '.');
        if (l.source.width !== g.w || l.source.height !== g.h || Math.abs(l.source.pixelAspect-r.par) > 0.00001) fail('EXR dimensions / interpretation do not match expected ' + g.w + ' x ' + g.h + ', PAR ' + r.par + '. Check crop, resize, render resolution and Interpret Footage.');
        if (l.source.useProxy) fail('Disable the footage proxy before aligning.');
        if (l.locked || l.parent !== null || l.threeDLayer) fail('Patch must be unlocked, unparented and 2D.');
        var ap = tr.property('ADBE Anchor Point'), pos = tr.property('ADBE Position'), sc = tr.property('ADBE Scale'), rot = tr.property('ADBE Rotate Z');
        propStatic(ap); propStatic(sc); propStatic(rot);
        var separated = pos.dimensionsSeparated, px, py;
        if (separated) { px = pos.getSeparationFollower(0); py = pos.getSeparationFollower(1); propStatic(px); propStatic(py); } else propStatic(pos);
        var old = {a:ap.value, p:separated ? [px.value,py.value] : pos.value, s:sc.value, r:rot.value};
        app.beginUndoGroup('Align ROI Patch');
        try {
            try {
                ap.setValue([g.w/2,g.h/2]); sc.setValue([100,100]); rot.setValue(0);
                if (separated) { px.setValue(r.left+g.w/2); py.setValue(r.top+g.h/2); } else pos.setValue([r.left+g.w/2,r.top+g.h/2]);
            } catch (e) {
                try { ap.setValue(old.a); sc.setValue(old.s); rot.setValue(old.r); if (separated) { px.setValue(old.p[0]); py.setValue(old.p[1]); } else pos.setValue(old.p); } catch (rollback) { fail('Alignment failed; use Edit > Undo to restore the layer. ' + e.message); }
                throw e;
            }
        } finally { app.endUndoGroup(); }
        return 'Aligned: anchor ' + g.w/2 + ', ' + g.h/2 + '; position ' + (r.left+g.w/2) + ', ' + (r.top+g.h/2) + '; scale 100%; rotation 0.';
    }

    function ready(){if(!app.project)fail('Open an AE project.');if(app.project.renderQueue.rendering)fail('Wait until rendering finishes.');load();}
    function record(id){for(var i=0;i<records.length;i++)if(records[i].id===id)return records[i];fail('Saved patch not found. Reload records and choose again.');}
    function queueEntries(){var out=[],pick=-1,rq=app.project.renderQueue;for(var i=1;i<=rq.numItems;i++){var it=rq.item(i);for(var j=1;j<=it.numOutputModules;j++){var om=it.outputModule(j),path=om.file?om.file.fsName:'';out.push({index:i,module:j,compID:it.comp.id,path:path,label:'#'+i+' / OM '+j+'  '+it.comp.name+' > '+(om.file?File.decode(om.file.name):'(no output)')});if(it.status===RQItemStatus.QUEUED)pick=out.length-1;}}return {entries:out,preferred:pick>=0?pick:out.length-1};}
    function info(c,a){ready();var q=queueEntries();return {ok:true,message:loadError||('Loaded '+records.length+' saved ROI patches.'),loadError:loadError,records:records,entries:q.entries,preferred:q.preferred};}
    function sourceEntry(a){var e=a.entry,rq=app.project.renderQueue;if(!e||!integer(e.index)||e.index<1||!integer(e.module)||e.module<1||e.index>rq.numItems)fail('Queue an EXR render, then refresh the queue.');var it=rq.item(e.index);if(e.module>it.numOutputModules)fail('Output modules changed. Refresh the queue.');var om=it.outputModule(e.module);if(it.comp.id!==e.compID||(om.file?om.file.fsName:'')!==e.path)fail('Queue changed. Refresh the queue and choose the render again.');return {item:it,om:om,module:e.module};}
    function captureAction(c,a){ready();if(loadError)fail(loadError);var s=sourceEntry(a),comp=s.item.comp,o=inspectOM(s.om),path=s.om.file;
        if(!path||!/\.exr$/i.test(path.name))fail('Choose an output module with an EXR filename.');
        if(!enabled(setting(o,'Crop')))fail('Enable Crop > Use Region of Interest in Output Module Settings, then close that dialog.');
        if(enabled(setting(o,'Resize')))fail('Disable output-module Resize. Unscaled crops only.');
        var rs=s.item.getSettings(GetSettingsFormat.STRING),res=setting(rs,'Resolution');if(String(res).toLowerCase()!=='full')fail('Set Render Settings > Resolution to Full. Received: '+res+'.');
        var r={id:'roi-'+new Date().getTime()+'-'+Math.floor(Math.random()*1000000),name:comp.name+' - '+File.decode(path.name),path:path.fsName,width:comp.width,height:comp.height,par:comp.pixelAspect,left:num(setting(o,'Crop Left')),top:num(setting(o,'Crop Top')),right:num(setting(o,'Crop Right')),bottom:num(setting(o,'Crop Bottom')),project:app.project.file?app.project.file.fsName:'(unsaved)',comp:comp.name,captured:String(new Date()),ae:app.version};valid(r);var g=geometry(r);
        if(!confirm('Capture this output? Verify against Output Module Settings.\n\n'+r.path+'\nMaster '+r.width+' x '+r.height+'\nCrop Left / Top / Right / Bottom: '+[r.left,r.top,r.right,r.bottom].join(' / ')+'\nExpected EXR '+g.w+' x '+g.h+'\n\nCapture again if ROI or render settings change.'))return {ok:true,message:'ROI capture cancelled.'};
        var name=prompt('Patch label',r.name);if(name===null)return {ok:true,message:'ROI capture cancelled.'};if(!name.replace(/\s/g,''))fail('Patch label cannot be empty.');r.name=name;var next=[],replaced=0;for(var ri=0;ri<records.length;ri++){if(norm(records[ri].path).toLowerCase()!==norm(r.path).toLowerCase())next.push(records[ri]);else replaced++;}if(replaced&&!confirm('Replace '+replaced+' previous capture(s) for this exact output path?\n'+r.path+'\n\nUse a different render filename to keep separate patches.'))return {ok:true,message:'ROI capture cancelled.'};next.push(r);save(next);return {ok:true,message:'Saved ROI. Render normally in AE, then import the EXR and Align Patch.',recordId:r.id};
    }
    function alignAction(c,a){ready();if(loadError)fail(loadError);var t=target(),found=best(t.path),ids=[],i;
        if(!found.length)fail('No saved crop matches this EXR. Capture its own output filename in the source AEP first.');
        for(i=0;i<found.length;i++)ids.push(records[found[i]].id);
        var r=null;
        if(a.explicit&&a.recordId){r=record(a.recordId);if(!score(t.path,r.path))fail('Selected saved patch does not match this EXR. Choose its own capture.');}
        else if(found.length===1&&score(t.path,records[found[0]].path)>=3)r=records[found[0]];
        else return {ok:true,needsChoice:true,matchingIds:ids,records:records,message:'Choose the saved crop for this EXR, check its details, then Align Patch again.'};
        if((found.length>1||score(t.path,r.path)<3)&&!confirm('Apply this saved crop to the selected EXR layer only?\n'+r.name+'\nSaved: '+r.path+'\nSelected: '+t.path+'\nCrop L/T/R/B '+[r.left,r.top,r.right,r.bottom].join(' / ')))return {ok:true,message:'Patch alignment cancelled.'};
        return {ok:true,message:align(r),recordId:r.id};
    }
    function inspectAction(c,a){ready();var s=sourceEntry(a);return {ok:true,message:'Queued output-module settings (read only).',settings:inspectOM(s.om)};}
    function matchAction(c,a){ready();if(loadError)fail(loadError);var found=best(target().path),ids=[];for(var i=0;i<found.length;i++)ids.push(records[found[i]].id);if(!ids.length)fail('No filename match. Capture this output in the source project, or import its records.');return {ok:true,message:ids.length===1?'Matched saved patch.':'Several captures match. Choose the intended crop.',matchingIds:ids,records:records,recordId:ids.length===1?ids[0]:null,needsChoice:ids.length>1};}
    function exportAction(c,a){ready();if(loadError)fail(loadError);var f=File.saveDialog('Export all ROI records','*.json');if(!f)return {ok:true,message:'Record export cancelled.'};if(norm(f.fsName)===norm(db.fsName))fail('Choose a different export location.');f.encoding='UTF-8';if(!f.open('w'))fail('Cannot write export');try{if(!f.write(encode({schema:1,version:VERSION,records:records})))fail('Export write failed');}finally{f.close();}return {ok:true,message:'Exported ROI records to '+f.fsName};}
    function importAction(c,a){ready();if(loadError)fail(loadError);var f=File.openDialog('Import ROI records','*.json');if(!f)return {ok:true,message:'Record import cancelled.'};var incoming=parseDB(read(f)),next=records.slice(0),ids={},i;for(i=0;i<next.length;i++)ids[next[i].id]=encode(next[i]);for(i=0;i<incoming.length;i++){if(own(ids,incoming[i].id)){if(ids[incoming[i].id]!==encode(incoming[i]))fail('Conflicting record ID; import refused.');}else{next.push(incoming[i]);ids[incoming[i].id]=encode(incoming[i]);}}save(next);return {ok:true,message:'Imported ROI records. Total: '+records.length};}
    function deleteAction(c,a){ready();if(loadError)fail(loadError);var r=record(a.recordId);if(!confirm('Delete saved record "'+r.name+'"? Rendered files are unaffected.'))return {ok:true,message:'Record deletion cancelled.'};var next=[];for(var i=0;i<records.length;i++)if(records[i].id!==r.id)next.push(records[i]);save(next);return {ok:true,message:'Record deleted. Previous database is in records.json.bak.'};}
    function clearAction(c,a){ready();if(loadError)fail(loadError);if(!records.length)return {ok:true,message:'No saved patches to clear.'};
        if(!confirm('Clear all '+records.length+' saved patch records from this computer? This also clears the shared ROI Patch Manager list.\n\nRendered files and layer positions are unaffected. A backup is kept in records.json.bak.'))return {ok:true,message:'Clear cancelled.'};
        save([]);return {ok:true,message:'Saved patch list cleared. Rendered files are unchanged.'};}
    return {actions:{roiInfo:info,roiCapture:captureAction,roiAlign:alignAction,roiInspect:inspectAction,roiMatch:matchAction,roiExport:exportAction,roiImport:importAction,roiDelete:deleteAction,roiClear:clearAction}};
}());
