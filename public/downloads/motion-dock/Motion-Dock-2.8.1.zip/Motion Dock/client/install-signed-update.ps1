param([Parameter(Mandatory=$true)][string]$Archive,[Parameter(Mandatory=$true)][string]$Target,[Parameter(Mandatory=$true)][string]$ExpectedVersion,[Parameter(Mandatory=$true)][string]$ExpectedHash)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
function Hash([string]$Path){$stream=[IO.File]::OpenRead($Path);$sha=[Security.Cryptography.SHA256]::Create();try{return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose();$stream.Dispose()}}
function NoLinks([string]$Path){if((Get-Item -LiteralPath $Path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked installation paths are not supported.'}}
$targetRoot=[IO.Path]::GetFullPath($Target).TrimEnd('\')
if([IO.Path]::GetFileName($targetRoot) -ne 'studio.artist.motiondock'){throw 'Unexpected installation folder.'}
NoLinks $targetRoot
$parent=[IO.Directory]::GetParent($targetRoot)
while($parent){NoLinks $parent.FullName;$parent=$parent.Parent}
[xml]$installed=Get-Content -LiteralPath (Join-Path $targetRoot 'CSXS/manifest.xml') -Raw
if($installed.ExtensionManifest.ExtensionBundleId -ne 'studio.artist.motiondock'){throw 'Extension identity mismatch.'}
if($ExpectedVersion -notmatch '^\d{1,4}\.\d{1,4}\.\d{1,4}$' -or [version]$ExpectedVersion -le [version]$installed.ExtensionManifest.ExtensionBundleVersion){throw 'The update is already installed or older than this installation.'}
if($ExpectedHash -notmatch '^[a-f0-9]{64}$' -or (Hash $Archive) -ne $ExpectedHash){throw 'Downloaded signed package changed before installation.'}
$scratch=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Archive))
$tempRoot=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
if(!$scratch.StartsWith($tempRoot,[StringComparison]::OrdinalIgnoreCase) -or ![IO.Path]::GetFileName($scratch).StartsWith('motion-dock-update-')){throw 'Unexpected update staging folder.'}
NoLinks $scratch
$mutex=New-Object Threading.Mutex($false,('Local\MotionDockUpdate'+[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($targetRoot.ToLowerInvariant()))).Replace('-','')))
$held=$false
try{
 $held=$mutex.WaitOne(0)
 if(!$held){throw 'Another Motion Dock update is already running.'}
 # Another updater may have finished between the first check and acquiring the lock.
 [xml]$installed=Get-Content -LiteralPath (Join-Path $targetRoot 'CSXS/manifest.xml') -Raw
 if($installed.ExtensionManifest.ExtensionBundleId -ne 'studio.artist.motiondock' -or [version]$ExpectedVersion -le [version]$installed.ExtensionManifest.ExtensionBundleVersion){throw 'The installation changed. Check for updates again.'}
 $stage=Join-Path $scratch 'signed-extension'
 if(Test-Path -LiteralPath $stage){throw 'Update staging folder already exists.'}
 $zip=[IO.Compression.ZipFile]::OpenRead($Archive)
 $names=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 try{
  if($zip.Entries.Count -gt 512){throw 'Too many files in signed package.'}
  [long]$expanded=0
  foreach($entry in $zip.Entries){
   $name=$entry.FullName.Replace('\','/')
   if(!$name -or $name -match '^/|:|(^|/)\.\.?(/|$)|[\x00-\x1f]' -or (($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000){throw 'Unsafe signed package entry.'}
   foreach($part in $name.TrimEnd('/').Split('/')){if(!$part -or $part -match '[. ]$|[<>"|?*]' -or $part -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)'){throw 'Unsafe Windows package filename.'}}
   if($name -notmatch '^(client/|host/|CSXS/|META-INF/|READ ME\.txt$|mimetype$)'){throw 'Unexpected signed package content.'}
   if(!$names.Add($name)){throw 'Duplicate signed package entry.'}
   $resolved=[IO.Path]::GetFullPath((Join-Path $stage $name))
   if(!$resolved.StartsWith([IO.Path]::GetFullPath($stage)+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Package entry escapes staging folder.'}
   $expanded+=$entry.Length
   if($expanded -gt 64MB){throw 'Expanded signed package is too large.'}
  }
 }finally{$zip.Dispose()}
 [IO.Compression.ZipFile]::ExtractToDirectory($Archive,$stage)
 foreach($required in @('CSXS/manifest.xml','META-INF/signatures.xml','client/index.html','host/MotionDock.jsx','client/update-public-key.pem')){if(!(Test-Path -LiteralPath (Join-Path $stage $required) -PathType Leaf)){throw 'Signed package is incomplete.'}}
 [xml]$next=Get-Content -LiteralPath (Join-Path $stage 'CSXS/manifest.xml') -Raw
 if($next.ExtensionManifest.ExtensionBundleId -ne 'studio.artist.motiondock' -or $next.ExtensionManifest.ExtensionBundleVersion -ne $ExpectedVersion){throw 'Signed package identity/version mismatch.'}
 if((Hash (Join-Path $stage 'client/update-public-key.pem')) -ne (Hash (Join-Path $targetRoot 'client/update-public-key.pem'))){throw 'Update changes the pinned release key. A manual upgrade is required.'}
 $priorFiles=@(Get-ChildItem -LiteralPath $targetRoot -Force -Recurse)
 foreach($entry in $priorFiles){NoLinks $entry.FullName}
 foreach($entry in Get-ChildItem -LiteralPath $targetRoot -Force){if($entry.Name -notin @('client','host','CSXS','META-INF','READ ME.txt','mimetype')){throw 'Move custom files outside the extension folder before updating. Preferences and ROI records already live separately.'}}
 $nextFiles=@(Get-ChildItem -LiteralPath $stage -Recurse -File)
 $nextPaths=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 foreach($file in $nextFiles){$relative=$file.FullName.Substring($stage.Length).TrimStart('\');$null=$nextPaths.Add($relative);$dest=Join-Path $targetRoot $relative;if(Test-Path -LiteralPath $dest -PathType Container){throw 'A folder blocks an update file.'}}
 $backupRoot=Join-Path $env:APPDATA 'Motion Dock/updates/backups'
 New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
 $backup=Join-Path $backupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+$installed.ExtensionManifest.ExtensionBundleVersion+'-'+[guid]::NewGuid().ToString('N').Substring(0,8))
 New-Item -ItemType Directory -Path $backup | Out-Null
 foreach($file in $priorFiles | Where-Object {!$_.PSIsContainer}){$relative=$file.FullName.Substring($targetRoot.Length).TrimStart('\');$saved=Join-Path $backup $relative;New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($saved)) | Out-Null;Copy-Item -LiteralPath $file.FullName -Destination $saved;if((Hash $file.FullName) -ne (Hash $saved)){throw 'Backup verification failed. No installed files were changed.'}}
 $added=New-Object 'Collections.Generic.List[string]'
 try{
  # Copy signature metadata last; retain byte-identical files to avoid needless locks.
  foreach($file in $nextFiles | Sort-Object @{Expression={if($_.FullName -match '\\META-INF\\'){1}else{0}}},FullName){
   $relative=$file.FullName.Substring($stage.Length).TrimStart('\');$dest=Join-Path $targetRoot $relative
   if(Test-Path -LiteralPath $dest){if((Hash $dest) -eq (Hash $file.FullName)){continue}}else{$added.Add($dest)}
   New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($dest)) | Out-Null
   Copy-Item -LiteralPath $file.FullName -Destination $dest -Force
  }
  foreach($old in $priorFiles | Where-Object {!$_.PSIsContainer}){$relative=$old.FullName.Substring($targetRoot.Length).TrimStart('\');if(!$nextPaths.Contains($relative)){Remove-Item -LiteralPath $old.FullName -Force}}
  $actual=@(Get-ChildItem -LiteralPath $targetRoot -Force -Recurse -File)
  if($actual.Count -ne $nextFiles.Count){throw 'Installed file list does not match the signed package.'}
  foreach($file in $nextFiles){$relative=$file.FullName.Substring($stage.Length).TrimStart('\');if((Hash (Join-Path $targetRoot $relative)) -ne (Hash $file.FullName)){throw 'Installed signed-package verification failed.'}}
 }catch{
  $reason=$_.Exception.Message
  try{
   foreach($dest in $added){if(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Force}}
   foreach($saved in Get-ChildItem -LiteralPath $backup -Recurse -File){$relative=$saved.FullName.Substring($backup.Length).TrimStart('\');$dest=Join-Path $targetRoot $relative;if((Test-Path -LiteralPath $dest) -and (Hash $dest) -eq (Hash $saved.FullName)){continue};New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($dest)) | Out-Null;Copy-Item -LiteralPath $saved.FullName -Destination $dest -Force}
  }catch{throw "Update stopped. Restore the backup at $backup before reopening the panel. $reason"}
  throw "Update failed; previous files restored. $reason"
 }
 Write-Output "Installed signed Motion Dock $ExpectedVersion. Backup: $backup"
}finally{if($held){$mutex.ReleaseMutex()};$mutex.Dispose()}
