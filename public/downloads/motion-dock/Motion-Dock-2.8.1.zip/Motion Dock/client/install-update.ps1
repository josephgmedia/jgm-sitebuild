param([Parameter(Mandatory=$true)][string]$Archive,[Parameter(Mandatory=$true)][string]$Target,[Parameter(Mandatory=$true)][string]$ExpectedVersion,[Parameter(Mandatory=$true)][string]$ExpectedHash)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath (Join-Path $Target 'META-INF/signatures.xml')) { throw 'Signed installations must be updated using their ZXP installer.' }
Add-Type -AssemblyName System.IO.Compression.FileSystem
function FileHash([string]$Path) { $stream=[IO.File]::OpenRead($Path); $sha=[Security.Cryptography.SHA256]::Create(); try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose(); $stream.Dispose() } }
$targetRoot=[IO.Path]::GetFullPath($Target).TrimEnd('\')
if ([IO.Path]::GetFileName($targetRoot) -ne 'studio.artist.motiondock') { throw 'Unexpected installation folder.' }
[xml]$installed=Get-Content -LiteralPath (Join-Path $targetRoot 'CSXS/manifest.xml') -Raw
if ($installed.ExtensionManifest.ExtensionBundleId -ne 'studio.artist.motiondock') { throw 'Extension identity mismatch.' }
if ((FileHash $Archive) -ne $ExpectedHash) { throw 'Downloaded archive changed before installation.' }
$scratch=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Archive))
$tempRoot=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\'
if (!$scratch.StartsWith($tempRoot,[StringComparison]::OrdinalIgnoreCase) -or ![IO.Path]::GetFileName($scratch).StartsWith('motion-dock-update-')) { throw 'Unexpected update staging folder.' }
$stage=Join-Path $scratch 'extracted'
$zip=[IO.Compression.ZipFile]::OpenRead($Archive)
try {
  if ($zip.Entries.Count -gt 512) { throw 'Too many files in update archive.' }
  [long]$expanded=0
  foreach($entry in $zip.Entries) {
    $name=$entry.FullName.Replace('\','/')
    if ($name -notmatch '^Motion Dock/' -or $name -match '(^|/)\.\.?(/|$)|:|^/' -or (($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000) { throw 'Unsafe archive entry.' }
    $resolved=[IO.Path]::GetFullPath((Join-Path $stage $name))
    if (!$resolved.StartsWith([IO.Path]::GetFullPath($stage)+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Archive entry escapes staging folder.' }
    $expanded+=$entry.Length
    if ($expanded -gt 64MB) { throw 'Expanded update is too large.' }
  }
} finally { $zip.Dispose() }
[IO.Compression.ZipFile]::ExtractToDirectory($Archive,$stage)
$source=Join-Path $stage 'Motion Dock'
[xml]$next=Get-Content -LiteralPath (Join-Path $source 'CSXS/manifest.xml') -Raw
if ($next.ExtensionManifest.ExtensionBundleId -ne 'studio.artist.motiondock' -or $next.ExtensionManifest.ExtensionBundleVersion -ne $ExpectedVersion) { throw 'Update manifest does not match the verified release.' }
$backupRoot=Join-Path $env:APPDATA 'Motion Dock/updates/backups'
New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
$backup=Join-Path $backupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+$installed.ExtensionManifest.ExtensionBundleVersion)
New-Item -ItemType Directory -Path $backup | Out-Null
$plans=@()
foreach($directory in @('client','host','CSXS')) {
  $folder=Join-Path $source $directory
  if (!(Test-Path -LiteralPath $folder -PathType Container)) { throw 'Update package is incomplete.' }
  foreach($file in Get-ChildItem -LiteralPath $folder -Recurse -File) {
    $relative=$file.FullName.Substring($source.Length).TrimStart('\')
    $destination=[IO.Path]::GetFullPath((Join-Path $targetRoot $relative))
    if (!$destination.StartsWith($targetRoot+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe installation path.' }
    $prior=Join-Path $backup $relative
    $existed=Test-Path -LiteralPath $destination
    if ($existed) { New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($prior)) | Out-Null; Copy-Item -LiteralPath $destination -Destination $prior }
    $plans+=@{Source=$file.FullName;Destination=$destination;Backup=$prior;Existed=$existed}
  }
}
try {
  foreach($plan in $plans) {
    New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($plan.Destination)) | Out-Null
    Copy-Item -LiteralPath $plan.Source -Destination $plan.Destination -Force
    if ((FileHash $plan.Source) -ne (FileHash $plan.Destination)) { throw 'Installed file verification failed.' }
  }
} catch {
  $reason=$_
  foreach($plan in $plans) {
    if ($plan.Existed) { Copy-Item -LiteralPath $plan.Backup -Destination $plan.Destination -Force }
    elseif(Test-Path -LiteralPath $plan.Destination) { Remove-Item -LiteralPath $plan.Destination -Force }
  }
  throw "Update failed; previous files restored. $reason"
}
Write-Output "Installed Motion Dock $ExpectedVersion. Backup: $backup"
