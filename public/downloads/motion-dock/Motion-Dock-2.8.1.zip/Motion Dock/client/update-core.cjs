'use strict';
// The release key is pinned in the installed extension, not supplied by the feed.
const crypto = require('crypto');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const childProcess = require('child_process');
const FEED = 'https://www.josephgmedia.com/updates/motion-dock/latest.json';
const ID = 'studio.artist.motiondock';
function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
  return JSON.stringify(value);
}
function version(value) {
  if (!/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(value)) throw Error('Invalid release version.');
  return value.split('.').map(Number);
}
function newer(a, b) {
  const x = version(a), y = version(b);
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i];
  return false;
}
function trusted(value, download) {
  const u = new URL(value);
  if (u.protocol !== 'https:' || !['www.josephgmedia.com', 'josephgmedia.com'].includes(u.hostname) || u.port || u.username || u.password || u.hash || u.search) throw Error('Untrusted update address.');
  if (download ? !/^\/downloads\/motion-dock\/Motion-Dock-\d+\.\d+\.\d+\.(?:zip|zxp)$/.test(u.pathname) : u.pathname !== '/updates/motion-dock/latest.json') throw Error('Unexpected update path.');
  return u;
}
function verify(feed, publicKey) {
  if (!feed || !feed.release || typeof feed.signature !== 'string') throw Error('Invalid update feed.');
  const r = feed.release;
  if (r.schema !== 1 || r.extensionId !== ID || !crypto.verify('RSA-SHA256', Buffer.from(canonical(r)), publicKey, Buffer.from(feed.signature, 'base64'))) throw Error('The update signature could not be verified. Nothing was installed.');
  version(r.version); trusted(r.downloadUrl, true);
  if (!/^[a-f0-9]{64}$/.test(r.sha256) || !Number.isInteger(r.size) || r.size < 1 || r.size > 32 * 1024 * 1024 || !Array.isArray(r.notes) || r.notes.length > 20 || r.notes.some(n => typeof n !== 'string' || n.length > 2000)) throw Error('Invalid release details.');
  if (new URL(r.downloadUrl).pathname !== '/downloads/motion-dock/Motion-Dock-' + r.version + '.zip') throw Error('Release filename does not match its version.');
  if(r.installer){
    const z=r.installer;trusted(z.url,true);
    if(new URL(z.url).pathname!=='/downloads/motion-dock/Motion-Dock-'+r.version+'.zxp'||!Number.isInteger(z.size)||z.size<1||z.size>32*1024*1024||!/^[a-f0-9]{64}$/.test(z.sha256))throw Error('Invalid signed installer details.');
  }
  return r;
}
function get(url, limit, download, redirects) {
  return new Promise((resolve, reject) => {
    try { trusted(url, download); } catch (e) { reject(e); return; }
    const req = https.get(url, { headers: { 'User-Agent': 'Motion-Dock-Updater', 'Cache-Control': 'no-cache' } }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();
        if ((redirects || 0) >= 3 || !res.headers.location) return reject(Error('Too many update redirects.'));
        return get(new URL(res.headers.location, url).href, limit, download, (redirects || 0) + 1).then(resolve, reject);
      }
      if (res.statusCode !== 200) { res.resume(); return reject(Error('Update server returned ' + res.statusCode + '.')); }
      if (Number(res.headers['content-length']) > limit) { res.destroy(); return reject(Error('Update download exceeds its size limit.')); }
      const chunks = []; let size = 0;
      res.on('data', chunk => { size += chunk.length; if (size > limit) { res.destroy(); reject(Error('Update download exceeds its size limit.')); } else chunks.push(chunk); });
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('aborted', () => reject(Error('The update download was interrupted.')));
      res.on('error', reject);
    });
    req.setTimeout(30000, () => req.destroy(Error('The update request timed out.')));
    req.on('error', reject);
  });
}
async function check(extensionRoot) {
  const data = await get(FEED, 128 * 1024, false);
  return verify(JSON.parse(data.toString('utf8')), fs.readFileSync(path.join(extensionRoot, 'client', 'update-public-key.pem')));
}
function isSigned(extensionRoot){return fs.existsSync(path.join(extensionRoot,'META-INF','signatures.xml'));}
async function downloadInstaller(extensionRoot,offered,onProgress){
  const r=await check(extensionRoot);
  if(r.version!==offered.version||!r.installer||!offered.installer||r.installer.sha256!==offered.installer.sha256)throw Error('The installer offer changed. Check for updates again.');
  onProgress('Downloading signed Motion Dock '+r.version+'…');
  const z=r.installer,bytes=await get(z.url,z.size,true);
  if(bytes.length!==z.size||crypto.createHash('sha256').update(bytes).digest('hex')!==z.sha256)throw Error('The installer download did not pass verification.');
  const dir=path.join(os.homedir(),'Downloads','Motion Dock');fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,'Motion-Dock-'+r.version+'.zxp');
  if(fs.existsSync(file)&&crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==z.sha256)throw Error('A different file already exists at '+file+'. Move it aside and retry.');
  if(!fs.existsSync(file))fs.writeFileSync(file,bytes,{flag:'wx'});
  return {version:r.version,file:file,installerOnly:true};
}
function showInstaller(file){childProcess.execFile('explorer.exe',['/select,'+file],{windowsHide:true},function(){});}
async function installLegacy(extensionRoot, offered, onProgress) {
  if(isSigned(extensionRoot))throw Error('This installation is signed. Download the ZXP update and install it with your extension installer.');
  const target = fs.realpathSync(extensionRoot);
  if (path.basename(target).toLowerCase() !== ID) throw Error('Updates require the standard Motion Dock installation folder.');
  const xml = fs.readFileSync(path.join(target, 'CSXS', 'manifest.xml'), 'utf8');
  if (!xml.includes('ExtensionBundleId="' + ID + '"')) throw Error('This is not a Motion Dock installation.');
  const r = await check(target);
  if (r.version !== offered.version || r.sha256 !== offered.sha256) throw Error('The release changed. Check for updates again.');
  const current = /ExtensionBundleVersion="([^"]+)"/.exec(xml);
  if (!current || !newer(r.version, current[1])) throw Error('This update is already installed, or is older than your installed version.');
  onProgress('Downloading Motion Dock ' + r.version + '…');
  const bytes = await get(r.downloadUrl, r.size, true);
  if (bytes.length !== r.size || crypto.createHash('sha256').update(bytes).digest('hex') !== r.sha256) throw Error('The download did not pass verification. Nothing was installed.');
  const workspace = fs.mkdtempSync(path.join(os.tmpdir(), 'motion-dock-update-'));
  const archive = path.join(workspace, 'release.zip'); fs.writeFileSync(archive, bytes, { flag: 'wx' });
  onProgress('Installing verified update. Your settings and saved records are kept…');
  await new Promise((resolve, reject) => {
    childProcess.execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(target, 'client', 'install-update.ps1'), '-Archive', archive, '-Target', target, '-ExpectedVersion', r.version, '-ExpectedHash', r.sha256], { windowsHide: true, timeout: 120000, maxBuffer: 128 * 1024 }, (error, stdout, stderr) => {
      if (error) reject(Error((stderr || stdout || error.message).trim().slice(0, 1500))); else resolve();
    });
  });
  // Only remove this updater's own resolved temporary directory, never backups.
  try {
    const actual=fs.realpathSync(workspace), temporary=fs.realpathSync(os.tmpdir());
    if (actual.startsWith(temporary+path.sep) && path.basename(actual).startsWith('motion-dock-update-')) fs.rmSync(actual,{recursive:true,force:true});
  } catch (_) { /* Installation succeeded; temporary cleanup is best effort. */ }
  return r;
}
// Install the entire feed-authenticated ZXP, including Adobe signature metadata.
// The publisher verifies the Adobe signature before signing this feed's ZXP hash.
async function install(extensionRoot,offered,onProgress){
  const target=fs.realpathSync(extensionRoot);
  if(path.basename(target).toLowerCase()!==ID)throw Error('Updates require the standard Motion Dock installation folder.');
  const xml=fs.readFileSync(path.join(target,'CSXS','manifest.xml'),'utf8');
  if(!xml.includes('ExtensionBundleId="'+ID+'"'))throw Error('This is not a Motion Dock installation.');
  const r=await check(target),current=/ExtensionBundleVersion="([^"]+)"/.exec(xml);
  if(r.version!==offered.version||r.sha256!==offered.sha256)throw Error('The release changed. Check for updates again.');
  if(!current||!newer(r.version,current[1]))throw Error('This update is already installed, or is older than your installed version.');
  if(!r.installer)return installLegacy(target,offered,onProgress);
  if(!offered.installer||r.installer.sha256!==offered.installer.sha256)throw Error('The signed package changed. Check for updates again.');
  onProgress('Downloading signed Motion Dock '+r.version+'…');
  const z=r.installer,bytes=await get(z.url,z.size,true);
  if(bytes.length!==z.size||crypto.createHash('sha256').update(bytes).digest('hex')!==z.sha256)throw Error('The signed package did not pass verification. Nothing was installed.');
  const workspace=fs.mkdtempSync(path.join(os.tmpdir(),'motion-dock-update-'));
  const archive=path.join(workspace,'release.zxp'),worker=path.join(workspace,'install-signed-update.ps1');
  fs.writeFileSync(archive,bytes,{flag:'wx'});fs.copyFileSync(path.join(target,'client','install-signed-update.ps1'),worker);
  onProgress('Installing signed update and backing up the current version…');
  await new Promise((resolve,reject)=>{
    childProcess.execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',worker,'-Archive',archive,'-Target',target,'-ExpectedVersion',r.version,'-ExpectedHash',z.sha256],{windowsHide:true,timeout:240000,maxBuffer:128*1024},(error,stdout,stderr)=>{
      if(error)reject(Error((stderr||stdout||error.message).trim().slice(0,1800)));else resolve();
    });
  });
  try{const actual=fs.realpathSync(workspace),temporary=fs.realpathSync(os.tmpdir());if(actual.startsWith(temporary+path.sep)&&path.basename(actual).startsWith('motion-dock-update-'))fs.rmSync(actual,{recursive:true,force:true});}catch(_){}
  return r;
}
module.exports = { canonical, version, newer, trusted, verify, check, install, isSigned, downloadInstaller, showInstaller, FEED, ID };
